
// 1. Critical Data Model Issues Addressed:
// §1.1 Discriminated Unions for Shape
// §1.2 Connector-to-Shape linkage
// §1.3 PCB Pad Data
// §1.11 Point Validation (Types)
// P1-04 Package/mounting type

export interface Point {
  x: number;
  y: number;
}

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

// --- SHAPES ---
export interface BaseShape {
  id: string;
  x: number;
  y: number;
  fill?: string;
  stroke?: string;
  strokeWidth?: number;
  opacity?: number;
  rotation?: number;
  rotationOrigin?: Point; // Added per P1-07
  visible?: boolean;
  name?: string;
  zIndex?: number;
}

export interface RectShape extends BaseShape {
  type: "rect";
  w: number;
  h: number;
  rx?: number;
  ry?: number;
}

export interface CircleShape extends BaseShape {
  type: "circle";
  r: number;
}

export interface PathShape extends BaseShape {
  type: "path";
  d: string;
}

export interface TextShape extends BaseShape {
  type: "text";
  content: string;
  fontSize: number;
  fontFamily?: string;
  textAnchor?: "start" | "middle" | "end";
}

export interface GroupShape extends BaseShape {
  type: "group";
  children: Shape[];
}

export type Shape = RectShape | CircleShape | PathShape | TextShape | GroupShape;

// --- CONNECTORS & PADS ---
export interface PadSpec {
  padShape: "round" | "square" | "oblong" | "custom";
  padWidth: number;
  padHeight: number;
  holeDiameter?: number;
  thermalRelief?: boolean;
}

export interface Connector {
  id: string; // Internal stable ID
  name: string;
  type: "male" | "female" | "pad" | "wire";
  direction?: "input" | "output" | "bidirectional" | "passive" | "power"; // Added per P1-09
  description?: string;
  
  // Linkage to visual representations
  shapeIds: {
    breadboard?: string;
    schematic?: string;
    pcb?: string;
  };
  
  // Terminal positions (1x1 snap points)
  breadboardTerminal?: Point;
  schematicTerminal?: Point;
  pcbTerminal?: Point;
  
  padSpec: PadSpec;
}

export interface Bus {
  id: string;
  name: string;
  nodeMembers: string[]; // references Connector.id
}

// --- METADATA ---
export interface PartMeta {
  moduleId: string; // UUID
  title: string;
  description: string;
  author: string;
  version: string;
  url?: string; // Product URL
  datasheetUrl?: string; // Specific Datasheet URL
  label: string; // RefDes prefix (R, U, C)
  family: string;
  manufacturer?: string; // Added: Manufacturer Name
  mpn?: string; // Added: Manufacturer Part Number
  tags: string[];
  mountingType: "through-hole" | "surface-mount" | "hybrid" | "none"; // Separated per P1-04
  packageType: string; // Separated per P1-04
  properties: Record<string, { value: string; showInLabel?: boolean }>;
}

export type ViewType = "breadboard" | "schematic" | "pcb";

export interface ViewData {
  shapes: Shape[];
  viewBox?: BoundingBox;
  enabled: boolean;
}

export interface PartState {
  meta: PartMeta;
  connectors: Connector[];
  buses: Bus[];
  views: {
    breadboard: ViewData;
    schematic: ViewData;
    pcb: ViewData;
  };
}

// --- GENERATORS ---
export type PackageFamily = 'DIP' | 'SOIC' | 'QFP' | 'QFN' | 'Header' | 'Resistor' | 'Capacitor';

export interface GenOptionsBase {
  family: PackageFamily;
  padShape: 'round' | 'square' | 'oblong' | 'rect';
}

export interface GenOptionsIC extends GenOptionsBase {
  family: 'DIP' | 'SOIC' | 'QFP' | 'QFN' | 'Header';
  pinCount: number;
  pitch_mm: number;
  rowSpacing_mm?: number; // For DIP/SOIC
  bodyWidth_mm?: number;  // For QFP/QFN
  bodyLength_mm?: number; // For QFP/QFN
  thermalPad?: boolean;
}

export interface GenOptionsDiscrete extends GenOptionsBase {
  family: 'Resistor' | 'Capacitor';
  packageCode: '0402' | '0603' | '0805' | '1206' | 'Axial-0.3' | 'Radial';
}

export type GenOptions = GenOptionsIC | GenOptionsDiscrete;

// --- VALIDATION ---
export interface ValidationIssue {
  id: string;
  level: 'error' | 'warning';
  message: string;
  view?: ViewType;
  elementId?: string;
}

// --- UI STATE ---
export type SelectionRef = 
  | { type: "shape"; id: string }
  | { type: "connector"; id: string };

export interface ReferenceImage {
  id: string;
  dataUrl: string;
  x: number;
  y: number;
  width: number;
  height: number;
  opacity: number;
  rotation: number;
}

export interface UIState {
  activeView: ViewType | "metadata";
  selection: SelectionRef[];
  pan: Point;
  zoom: number;
  gridEnabled: boolean;
  snapRadius: number;
  activeTool: "select" | "rect" | "circle" | "pin" | "measure" | "text";
  referenceImages: Record<ViewType, ReferenceImage | null>; // Added per P4-13
  clipboard?: Shape[]; // Added for Copy/Paste
  showCommandPalette: boolean; // Added for Command Palette
  validationIssues: ValidationIssue[]; // Store current validation state
  modals: {
    generator: boolean;
    validation: boolean;
    aiImport: boolean;
    modify: boolean;
  }
}

export interface AppState {
  part: PartState;
  ui: UIState;
}