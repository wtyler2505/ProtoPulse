
import { Point, PartState, Shape, Connector, BoundingBox, ViewType, PartMeta, ViewData, ValidationIssue } from './types';
import { GoogleGenAI } from "@google/genai";

// --- MATH & COORDINATES ---

export function screenToWorld(screenX: number, screenY: number, pan: Point, zoom: number): Point {
  return {
    x: (screenX - pan.x) / zoom,
    y: (screenY - pan.y) / zoom,
  };
}

export function worldToScreen(worldX: number, worldY: number, pan: Point, zoom: number): Point {
  return {
    x: worldX * zoom + pan.x,
    y: worldY * zoom + pan.y,
  };
}

export function calculateBoundingBox(shapes: Shape[]): BoundingBox {
  if (shapes.length === 0) return { x: 0, y: 0, width: 100, height: 100 };
  
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  
  function expand(s: Shape, ox = 0, oy = 0) {
      const sx = s.x + ox;
      const sy = s.y + oy;

      if (s.type === 'group') {
          s.children.forEach(c => expand(c, sx, sy));
          return;
      }
      let x1 = sx, y1 = sy, x2 = sx, y2 = sy;
      if (s.type === 'rect') {
        x2 = sx + s.w;
        y2 = sy + s.h;
      } else if (s.type === 'circle') {
        x1 = sx - s.r; y1 = sy - s.r;
        x2 = sx + s.r; y2 = sy + s.r;
      } else if (s.type === 'text') {
          // approximate text bounds
          x2 = sx + (s.content.length * s.fontSize * 0.6);
          y2 = sy + s.fontSize;
      }
      minX = Math.min(minX, x1);
      minY = Math.min(minY, y1);
      maxX = Math.max(maxX, x2);
      maxY = Math.max(maxY, y2);
  }

  shapes.forEach(s => expand(s));
  
  // Add padding
  const pad = 10;
  return {
    x: minX - pad,
    y: minY - pad,
    width: (maxX - minX) + pad * 2,
    height: (maxY - minY) + pad * 2
  };
}

export function generateUUID(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

export function generateNextPinName(connectors: Connector[]): string {
  if (connectors.length === 0) return "1";
  
  // Try to find a pattern in the last added connector's name
  const last = connectors[connectors.length - 1].name;
  const match = last.match(/^(.*?)(\d+)$/);
  
  if (match) {
    const prefix = match[1];
    const numStr = match[2];
    const num = parseInt(numStr, 10);
    // Keep zero-padding if present
    const isZeroPadded = numStr.startsWith('0') && numStr.length > 1;
    const nextNumStr = (num + 1).toString();
    const finalNumStr = isZeroPadded ? nextNumStr.padStart(numStr.length, '0') : nextNumStr;
    return `${prefix}${finalNumStr}`;
  }
  
  // Fallback to simple counting if no numeric suffix
  return `${connectors.length + 1}`;
}

export function alignShapes(shapes: Shape[], ids: string[], type: 'left' | 'center-h' | 'right' | 'top' | 'center-v' | 'bottom' | 'dist-h' | 'dist-v'): Shape[] {
    const selected = shapes.filter(s => ids.includes(s.id));
    if (selected.length < 2) return shapes;
    
    // Helper to get center
    const getC = (s: Shape) => {
        if (s.type === 'rect') return { x: s.x + s.w/2, y: s.y + s.h/2 };
        if (s.type === 'circle') return { x: s.x, y: s.y };
        if (s.type === 'text') return { x: s.x, y: s.y }; // approximate
        if (s.type === 'group') return { x: s.x, y: s.y }; // group origin
        return { x: s.x, y: s.y };
    };

    let newVal: number;
    switch (type) {
        case 'left':
            newVal = Math.min(...selected.map(s => s.type === 'circle' ? s.x - s.r : s.x));
            return shapes.map(s => ids.includes(s.id) ? { ...s, x: s.type === 'circle' ? newVal + s.r : newVal } : s);
        case 'right':
            newVal = Math.max(...selected.map(s => s.type === 'rect' ? s.w + s.x : (s.type === 'circle' ? s.x + s.r : s.x)));
            return shapes.map(s => ids.includes(s.id) ? { ...s, x: s.type === 'rect' ? newVal - s.w : (s.type === 'circle' ? newVal - s.r : newVal) } : s);
        case 'top':
            newVal = Math.min(...selected.map(s => s.type === 'circle' ? s.y - s.r : s.y));
            return shapes.map(s => ids.includes(s.id) ? { ...s, y: s.type === 'circle' ? newVal + s.r : newVal } : s);
        case 'bottom':
            newVal = Math.max(...selected.map(s => s.type === 'rect' ? s.y + s.h : (s.type === 'circle' ? s.y + s.r : s.y)));
            return shapes.map(s => ids.includes(s.id) ? { ...s, y: s.type === 'rect' ? newVal - s.h : (s.type === 'circle' ? newVal - s.r : newVal) } : s);
        case 'center-h':
            const avgX = selected.reduce((sum, s) => sum + getC(s).x, 0) / selected.length;
            return shapes.map(s => {
                if (!ids.includes(s.id)) return s;
                const c = getC(s);
                return { ...s, x: s.x + (avgX - c.x) };
            });
        case 'center-v':
            const avgY = selected.reduce((sum, s) => sum + getC(s).y, 0) / selected.length;
            return shapes.map(s => {
                if (!ids.includes(s.id)) return s;
                const c = getC(s);
                return { ...s, y: s.y + (avgY - c.y) };
            });
        case 'dist-h':
            const sortedX = [...selected].sort((a, b) => getC(a).x - getC(b).x);
            const startX = getC(sortedX[0]).x;
            const endX = getC(sortedX[sortedX.length - 1]).x;
            const stepX = (endX - startX) / (sortedX.length - 1);
            return shapes.map(s => {
                if (!ids.includes(s.id)) return s;
                const idx = sortedX.findIndex(sx => sx.id === s.id);
                const c = getC(s);
                const targetX = startX + (idx * stepX);
                return { ...s, x: s.x + (targetX - c.x) };
            });
        case 'dist-v':
            const sortedY = [...selected].sort((a, b) => getC(a).y - getC(b).y);
            const startY = getC(sortedY[0]).y;
            const endY = getC(sortedY[sortedY.length - 1]).y;
            const stepY = (endY - startY) / (sortedY.length - 1);
            return shapes.map(s => {
                if (!ids.includes(s.id)) return s;
                const idx = sortedY.findIndex(sy => sy.id === s.id);
                const c = getC(s);
                const targetY = startY + (idx * stepY);
                return { ...s, y: s.y + (targetY - c.y) };
            });
        default: return shapes;
    }
}

// --- VALIDATION ---

export function validatePart(part: PartState): ValidationIssue[] {
  const issues: ValidationIssue[] = [];

  // Metadata Checks
  if (!part.meta.title?.trim()) {
    issues.push({ id: 'meta-title', level: 'error', message: 'Part title is required.' });
  }
  if (!part.meta.family?.trim()) {
    issues.push({ id: 'meta-family', level: 'warning', message: 'Part family is recommended for grouping.' });
  }

  // View Checks
  (['breadboard', 'schematic', 'pcb'] as const).forEach(view => {
    if (part.views[view].enabled && part.views[view].shapes.length === 0) {
      issues.push({ id: `empty-${view}`, level: 'warning', message: `${view.charAt(0).toUpperCase() + view.slice(1)} view is enabled but empty.`, view });
    }
  });

  // Connector Checks
  if (part.connectors.length === 0) {
    issues.push({ id: 'no-connectors', level: 'warning', message: 'Part has no connectors (useful only for mechanical parts).' });
  }

  part.connectors.forEach((c, i) => {
    // Unplaced Connectors
    (['breadboard', 'schematic', 'pcb'] as const).forEach(view => {
      if (part.views[view].enabled && !c.shapeIds[view]) {
        issues.push({ id: `unplaced-${c.id}-${view}`, level: 'error', message: `Connector "${c.name}" is missing in ${view} view.`, view, elementId: c.id });
      }
    });

    // Overlap Checks (Simple distance check against other connectors)
    for (let j = i + 1; j < part.connectors.length; j++) {
        const other = part.connectors[j];
        (['breadboard', 'schematic', 'pcb'] as const).forEach(view => {
            if (!part.views[view].enabled) return;
            // Get positions via terminals
            const getPos = (conn: Connector) => {
                if (view === 'breadboard') return conn.breadboardTerminal;
                if (view === 'schematic') return conn.schematicTerminal;
                if (view === 'pcb') return conn.pcbTerminal;
                return null;
            };
            const p1 = getPos(c);
            const p2 = getPos(other);
            
            if (p1 && p2) {
                const dist = Math.hypot(p1.x - p2.x, p1.y - p2.y);
                if (dist < 2) { // Threshold: 2 units
                    issues.push({ id: `overlap-${c.id}-${other.id}-${view}`, level: 'warning', message: `Connectors "${c.name}" and "${other.name}" overlap in ${view}.`, view, elementId: c.id });
                }
            }
        });
    }
  });

  return issues;
}

// --- EXPORT LOGIC (FZP XML & SVG) ---

function escapeXml(unsafe: string): string {
    return unsafe.replace(/[<>&'"]/g, function (c) {
        switch (c) {
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '&': return '&amp;';
            case '\'': return '&apos;';
            case '"': return '&quot;';
            default: return c;
        }
    });
}

function renderShapeToSvg(s: Shape, shapeToFritzingId?: Map<string, string>): string {
  const exportId = shapeToFritzingId ? (shapeToFritzingId.get(s.id) || s.id) : s.id;
  
  if (s.type === 'group') {
      const groupTransform = `translate(${s.x},${s.y})`;
      const combinedTransform = s.rotation 
          ? `${groupTransform} rotate(${s.rotation}, ${s.rotationOrigin?.x ?? 0}, ${s.rotationOrigin?.y ?? 0})` 
          : groupTransform;
      
      const groupCommon = `id="${exportId}" opacity="${s.opacity ?? 1}" transform="${combinedTransform}"`;
      const children = s.children.map(c => renderShapeToSvg(c, shapeToFritzingId)).join('\n');
      return `<g ${groupCommon}>\n${children}\n</g>`;
  }

  const rotationStr = s.rotation ? `transform="rotate(${s.rotation}, ${s.rotationOrigin?.x ?? s.x}, ${s.rotationOrigin?.y ?? s.y})"` : '';
  const common = `id="${exportId}" fill="${s.fill || 'none'}" stroke="${s.stroke || 'none'}" stroke-width="${s.strokeWidth || 0}" opacity="${s.opacity ?? 1}" ${rotationStr}`;
  
  switch (s.type) {
    case 'rect':
      return `<rect x="${s.x}" y="${s.y}" width="${s.w}" height="${s.h}" rx="${s.rx || 0}" ry="${s.ry || 0}" ${common} />`;
    case 'circle':
      return `<circle cx="${s.x}" cy="${s.y}" r="${s.r}" ${common} />`;
    case 'text':
      // Force OCRA font for compatibility if not specified
      const font = s.fontFamily || 'OCRA';
      return `<text x="${s.x}" y="${s.y}" font-family="${font}" font-size="${s.fontSize}" text-anchor="${s.textAnchor || 'start'}" ${common}>${escapeXml(s.content)}</text>`;
    case 'path':
      return `<path d="${s.d}" ${common} />`;
    default:
      return '';
  }
}

function generateSvgContent(viewId: string, shapes: Shape[], connectors: Connector[], bb: BoundingBox, unit: 'in' | 'mm'): string {
  let content = `<?xml version="1.0" encoding="UTF-8"?>\n`;
  content += `<svg xmlns="http://www.w3.org/2000/svg" xmlns:fritzing="http://fritzing.org/ns/0.1" version="1.2" `;
  
  let viewBox = `${bb.x} ${bb.y} ${bb.width} ${bb.height}`;
  let widthVal = unit === 'in' ? (bb.width * 0.01).toFixed(4) : (bb.width * 0.254).toFixed(4);
  let heightVal = unit === 'in' ? (bb.height * 0.01).toFixed(4) : (bb.height * 0.254).toFixed(4);

  if (viewId === 'icon') {
      const aspect = bb.width / bb.height;
      if (aspect > 1) {
          widthVal = "0.3";
          heightVal = (0.3 / aspect).toFixed(4);
      } else {
          heightVal = "0.3";
          widthVal = (0.3 * aspect).toFixed(4);
      }
  }
  
  content += `width="${widthVal}${unit}" height="${heightVal}${unit}" viewBox="${viewBox}">\n`;

  const shapeToFritzingId = new Map<string, string>();
  connectors.forEach((c, idx) => {
    if (viewId === 'pcb') {
      if (c.shapeIds.pcb) shapeToFritzingId.set(c.shapeIds.pcb, `connector${idx}pad`);
    } else {
      const sid = viewId === 'breadboard' ? c.shapeIds.breadboard : c.shapeIds.schematic;
      if (sid) shapeToFritzingId.set(sid, `connector${idx}pin`);
    }
  });
  
  if (viewId === 'pcb') {
    content += `  <g id="silkscreen">\n`;
    shapes.filter(s => s.zIndex !== 1).forEach(s => { 
        if (!shapeToFritzingId.has(s.id)) content += `    ${renderShapeToSvg(s)}\n`; 
    });
    content += `  </g>\n`;
    
    let thtPads = '';
    let smdPads = '';
    connectors.forEach((c, idx) => {
      const shapeId = c.shapeIds.pcb;
      const shape = shapes.find(s => s.id === shapeId);
      if (!shape) return;
      const isSMD = c.padSpec.holeDiameter === undefined || c.padSpec.holeDiameter === 0;
      const rendered = renderShapeToSvg(shape, shapeToFritzingId);
      if (isSMD) smdPads += `    ${rendered}\n`;
      else thtPads += `      ${rendered}\n`;
    });

    content += `  <g id="copper1">\n`;
    if (thtPads) {
        content += `    <g id="copper0">\n${thtPads}    </g>\n`;
    }
    content += smdPads;
    content += `  </g>\n`;

  } else {
    const layerId = viewId === 'icon' ? 'icon' : viewId;
    content += `  <g id="${layerId}">\n`;
    shapes.forEach(s => { content += `    ${renderShapeToSvg(s, shapeToFritzingId)}\n`; });
    
    if (viewId !== 'icon') {
        connectors.forEach((c, idx) => {
           const exportId = `connector${idx}`;
           let tx = 0, ty = 0;
           if (viewId === 'breadboard' && c.breadboardTerminal) { tx = c.breadboardTerminal.x; ty = c.breadboardTerminal.y; }
           else if (viewId === 'schematic' && c.schematicTerminal) { tx = c.schematicTerminal.x; ty = c.schematicTerminal.y; }
           else {
               const shapeId = viewId === 'breadboard' ? c.shapeIds.breadboard : c.shapeIds.schematic;
               const shape = shapes.find(s => s.id === shapeId);
               if (shape) {
                   tx = shape.x; ty = shape.y;
                   if (shape.type === 'rect') { tx += shape.w/2; ty += shape.h/2; }
                   if (shape.type === 'circle') { /* center is x,y */ }
               }
           }
           content += `    <rect id="${exportId}terminal" x="${tx}" y="${ty}" width="1" height="1" fill="none" stroke="none" stroke-width="0" />\n`;
        });
    }
    content += `  </g>\n`;
  }
  
  content += `</svg>`;
  return content;
}

function generateFzpXml(state: PartState): string {
  const meta = state.meta;
  const now = new Date();
  const date = now.toISOString().split('T')[0];
  const guid = meta.moduleId || generateUUID();
  
  let xml = `<?xml version="1.0" encoding="UTF-8"?>\n`;
  xml += `<module fritzingVersion="0.9.3b" moduleId="${guid}">\n`;
  xml += `  <version>${escapeXml(meta.version)}</version>\n`;
  xml += `  <title>${escapeXml(meta.title)}</title>\n`;
  xml += `  <description>${escapeXml(meta.description)}</description>\n`;
  xml += `  <author>${escapeXml(meta.author)}</author>\n`;
  xml += `  <date>${date}</date>\n`;
  xml += `  <url>${escapeXml(meta.url || '')}</url>\n`;
  xml += `  <label>${escapeXml(meta.label)}</label>\n`;
  
  xml += `  <tags>\n`;
  meta.tags.forEach(t => xml += `    <tag>${escapeXml(t)}</tag>\n`);
  xml += `  </tags>\n`;
  
  xml += `  <properties>\n`;
  xml += `    <property name="family">${escapeXml(meta.family)}</property>\n`;
  xml += `    <property name="package">${escapeXml(meta.packageType)}</property>\n`;
  if (meta.mountingType !== 'none') {
      xml += `    <property name="mounting">${escapeXml(meta.mountingType)}</property>\n`;
  }
  if (meta.manufacturer) {
    xml += `    <property name="manufacturer">${escapeXml(meta.manufacturer)}</property>\n`;
  }
  if (meta.mpn) {
    xml += `    <property name="part number">${escapeXml(meta.mpn)}</property>\n`;
  }
  if (meta.datasheetUrl) {
      xml += `    <property name="datasheet">${escapeXml(meta.datasheetUrl)}</property>\n`;
  }
  Object.entries(meta.properties).forEach(([k, v]) => {
     xml += `    <property name="${escapeXml(k)}"${v.showInLabel ? ' showInLabel="yes"' : ''}>${escapeXml(v.value)}</property>\n`;
  });
  xml += `  </properties>\n`;
  
  xml += `  <views>\n`;
  xml += `    <breadboardView>\n      <layers image="svg.breadboard.${guid}_breadboard.svg">\n        <layer layerId="breadboard"/>\n      </layers>\n    </breadboardView>\n`;
  xml += `    <schematicView>\n      <layers image="svg.schematic.${guid}_schematic.svg">\n        <layer layerId="schematic"/>\n      </layers>\n    </schematicView>\n`;
  xml += `    <pcbView>\n      <layers image="svg.pcb.${guid}_pcb.svg">\n        <layer layerId="copper0"/>\n        <layer layerId="copper1"/>\n        <layer layerId="silkscreen"/>\n      </layers>\n    </pcbView>\n`;
  xml += `    <iconView>\n      <layers image="svg.icon.${guid}_icon.svg">\n        <layer layerId="icon"/>\n      </layers>\n    </iconView>\n`;
  xml += `  </views>\n`;
  
  xml += `  <connectors>\n`;
  state.connectors.forEach((c, idx) => {
    const exportId = `connector${idx}`;
    const isSMD = c.padSpec.holeDiameter === undefined || c.padSpec.holeDiameter === 0;
    xml += `    <connector id="${exportId}" name="${escapeXml(c.name)}" type="${c.type}">\n`;
    xml += `      <description>${escapeXml(c.description || '')}</description>\n`;
    xml += `      <views>\n`;
    xml += `        <breadboardView>\n          <p layer="breadboard" svgId="${exportId}pin" terminalId="${exportId}terminal"/>\n        </breadboardView>\n`;
    xml += `        <schematicView>\n          <p layer="schematic" svgId="${exportId}pin" terminalId="${exportId}terminal"/>\n        </schematicView>\n`;
    xml += `        <pcbView>\n`;
    if (isSMD) {
        xml += `          <p layer="copper1" svgId="${exportId}pad"/>\n`;
    } else {
        xml += `          <p layer="copper0" svgId="${exportId}pad"/>\n`;
        xml += `          <p layer="copper1" svgId="${exportId}pad"/>\n`;
    }
    xml += `        </pcbView>\n`;
    xml += `      </views>\n`;
    xml += `    </connector>\n`;
  });
  xml += `  </connectors>\n`;
  
  if (state.buses.length > 0) {
      xml += `  <buses>\n`;
      state.buses.forEach(b => {
         xml += `    <bus id="${escapeXml(b.id)}" name="${escapeXml(b.name)}">\n`;
         b.nodeMembers.forEach(nm => {
             const originalIdx = state.connectors.findIndex(c => c.id === nm);
             if(originalIdx !== -1) {
                 xml += `      <nodeMember connectorId="connector${originalIdx}"/>\n`;
             }
         });
         xml += `    </bus>\n`;
      });
      xml += `  </buses>\n`;
  }
  
  xml += `</module>`;
  return xml;
}

export async function exportFzpz(state: PartState) {
  try {
    const issues = validatePart(state);
    const errors = issues.filter(i => i.level === 'error');
    if (errors.length > 0) {
        throw new Error("Validation Failed: " + errors.map(e => e.message).join("\n"));
    }

    // @ts-ignore
    const JSZip = window.JSZip;
    if (!JSZip) { alert("JSZip library not loaded."); return; }
    
    const zip = new JSZip();
    const guid = state.meta.moduleId || generateUUID();
    
    // 1. Generate FZP XML
    const xml = generateFzpXml(state);
    zip.file(`part.${guid}.fzp`, xml);
    
    // 2. Generate SVGs
    const getBb = (v: 'breadboard'|'schematic'|'pcb') => state.views[v].enabled ? calculateBoundingBox(state.views[v].shapes) : { x: 0, y: 0, width: 1, height: 1 };
    
    const bbBox = getBb('breadboard');
    const schBox = getBb('schematic');
    const pcbBox = getBb('pcb');
    
    const svgBB = generateSvgContent('breadboard', state.views.breadboard.enabled ? state.views.breadboard.shapes : [], state.connectors, bbBox, 'in');
    const svgSch = generateSvgContent('schematic', state.views.schematic.enabled ? state.views.schematic.shapes : [], state.connectors, schBox, 'in');
    const svgPcb = generateSvgContent('pcb', state.views.pcb.enabled ? state.views.pcb.shapes : [], state.connectors, pcbBox, 'mm');
    const svgIcon = generateSvgContent('icon', state.views.breadboard.enabled ? state.views.breadboard.shapes : [], state.connectors, bbBox, 'in');
    
    zip.file(`svg.breadboard.${guid}_breadboard.svg`, svgBB);
    zip.file(`svg.schematic.${guid}_schematic.svg`, svgSch);
    zip.file(`svg.pcb.${guid}_pcb.svg`, svgPcb);
    zip.file(`svg.icon.${guid}_icon.svg`, svgIcon);
    
    const content = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(content);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${state.meta.title.replace(/\s+/g, '_') || 'part'}.fzpz`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
  } catch (err) {
      console.error("Export failed:", err);
      // Re-throw to let UI handle it
      throw err;
  }
}

export async function suggestDescription(title: string, apiKey: string): Promise<string> {
  if (!apiKey) throw new Error("API Key is required");
  const ai = new GoogleGenAI({ apiKey });
  
  try {
    const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Provide a concise technical description (1-2 sentences) for an electronic component with the title "${title}".`,
    });
    return response.text?.trim() || '';
  } catch (e) {
      console.error("AI Generation failed", e);
      throw e;
  }
}

export async function extractPinsFromText(text: string, apiKey: string): Promise<any[]> {
    if (!apiKey) throw new Error("API Key is required");
    const ai = new GoogleGenAI({ apiKey });
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Extract the pinout table from the following text.
RULES:
- Output ONLY valid JSON array, no explanation
- Each pin: {"name": string, "type": "male"|"female"|"pad"|"wire", "description": string}
- Pin names should be concise (e.g. "VCC", "GND", "D0")
- Default type to "male" if unknown
TEXT:
${text}`,
            config: {
                responseMimeType: "application/json"
            }
        });
        return JSON.parse(response.text?.trim() || '[]');
    } catch (e) {
        console.error("AI Extraction failed", e);
        throw e;
    }
}

export async function extractMetadataFromDatasheet(file: {mimeType: string, data: string}, apiKey: string): Promise<{meta: Partial<PartMeta>, connectors: Connector[]}> {
  if (!apiKey) throw new Error("API Key is required");
  const ai = new GoogleGenAI({ apiKey });

  try {
      const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image', // High efficiency for reading docs
          contents: {
             parts: [
                 { inlineData: file },
                 { text: `Analyze this datasheet. Extract the following information in JSON format:
                 
                 Structure:
                 {
                   "title": "Component Name",
                   "description": "Short technical description",
                   "label": "RefDes (U, R, C, etc)",
                   "manufacturer": "Manufacturer Name",
                   "mpn": "Manufacturer Part Number",
                   "tags": ["tag1", "tag2"],
                   "pins": [
                      { "name": "VCC", "description": "Power Supply" },
                      { "name": "GND", "description": "Ground" }
                   ]
                 }
                 
                 If strict pinout isn't found, try to infer typical pins for this component type.
                 `}
             ]
          },
          config: {
              responseMimeType: "application/json"
          }
      });
      
      const text = response.text || "{}";
      const data = JSON.parse(text);
      
      const meta: Partial<PartMeta> = {
          title: data.title,
          description: data.description,
          label: data.label,
          manufacturer: data.manufacturer,
          mpn: data.mpn,
          tags: data.tags
      };

      const connectors: Connector[] = (data.pins || []).map((p: any, i: number) => ({
          id: generateUUID(),
          name: p.name || `Pin ${i+1}`,
          type: "male",
          description: p.description || "",
          padSpec: { padShape: 'round', padWidth: 2, padHeight: 2, holeDiameter: 0.8 },
          shapeIds: {}
      }));
      
      return { meta, connectors };
  } catch (e) {
      console.error("Datasheet extraction failed", e);
      throw e;
  }
}

export async function importFzpz(file: File): Promise<PartState | null> {
    // @ts-ignore
    const JSZip = window.JSZip;
    if (!JSZip) { 
        alert("JSZip library not loaded. Import unavailable."); 
        return null; 
    }

    try {
        const zip = new JSZip();
        const content = await zip.loadAsync(file);
        
        // Find .fzp file
        const fzpName = Object.keys(content.files).find(n => n.endsWith('.fzp'));
        if (!fzpName) throw new Error("Invalid FZPZ: No .fzp definition found.");

        const fzpXml = await content.file(fzpName).async("string");
        const parser = new DOMParser();
        const doc = parser.parseFromString(fzpXml, "text/xml");
        
        const module = doc.getElementsByTagName("module")[0];
        if (!module) throw new Error("Invalid FZP: No module tag.");
        
        const moduleId = module.getAttribute("moduleId") || generateUUID();
        
        // Helper to safely get text content
        const getText = (tag: string) => doc.getElementsByTagName(tag)[0]?.textContent || '';
        
        const meta: PartMeta = {
            moduleId,
            title: getText("title") || "Imported Part",
            description: getText("description"),
            author: getText("author"),
            version: getText("version"),
            url: getText("url"),
            label: getText("label"),
            family: "",
            packageType: "",
            mountingType: "through-hole",
            tags: Array.from(doc.getElementsByTagName("tag")).map(t => t.textContent || "").filter(Boolean),
            properties: {}
        };

        // Properties
        const props = doc.getElementsByTagName("property");
        for (let i = 0; i < props.length; i++) {
            const p = props[i];
            const name = p.getAttribute("name");
            const val = p.textContent || "";
            if (name === "family") meta.family = val;
            else if (name === "package") meta.packageType = val;
            else if (name === "mounting") meta.mountingType = val as any;
            else if (name === "datasheet") meta.datasheetUrl = val;
            else if (name === "manufacturer") meta.manufacturer = val;
            else if (name === "part number") meta.mpn = val;
            else if (name) {
                meta.properties[name] = { 
                    value: val, 
                    showInLabel: p.getAttribute("showInLabel") === "yes" 
                };
            }
        }

        // Connectors
        const connectors: Connector[] = [];
        const conns = doc.getElementsByTagName("connector");
        for (let i = 0; i < conns.length; i++) {
            const c = conns[i];
            const name = c.getAttribute("name") || `Pin ${i+1}`;
            const type = c.getAttribute("type") || "male";
            const desc = c.getElementsByTagName("description")[0]?.textContent || "";
            
            connectors.push({
                id: generateUUID(),
                name,
                type: type as any,
                description: desc,
                padSpec: { padShape: 'round', padWidth: 2, padHeight: 2, holeDiameter: 1 },
                shapeIds: { breadboard: undefined, schematic: undefined, pcb: undefined }
            });
        }
        
        return {
            meta,
            connectors,
            buses: [],
            views: {
                breadboard: { shapes: [], enabled: true },
                schematic: { shapes: [], enabled: true },
                pcb: { shapes: [], enabled: true }
            }
        };

    } catch (err) {
        console.error("Import error:", err);
        alert("Failed to import file: " + (err instanceof Error ? err.message : String(err)));
        return null;
    }
}
