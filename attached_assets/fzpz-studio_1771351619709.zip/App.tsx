
import React, { useState, useReducer, useRef, useEffect, useMemo } from 'react';
import { 
  Search, Box, Upload, Download, Undo2, Redo2, MousePointer2, 
  Square, Circle as CircleIcon, Type, Plug, Ruler, 
  AlignHorizontalJustifyCenter, AlignVerticalJustifyCenter, AlignLeft, AlignRight, 
  AlignVerticalJustifyStart, AlignVerticalJustifyEnd,
  AlignHorizontalDistributeCenter, AlignVerticalDistributeCenter, Eye, EyeOff, X, 
  AlertTriangle, Check, Loader, Sparkles, Trash2, Info, AlertCircle, Wand2, Paperclip, FileText, Link, Move
} from 'lucide-react';
import { 
  AppState, ViewType, Shape, Point, Connector, PartMeta, 
  SelectionRef, UIState, PadSpec, ReferenceImage, GroupShape, 
  ValidationIssue, GenOptions, PackageFamily
} from './types';
import { 
  screenToWorld, exportFzpz, generateUUID, suggestDescription, 
  generateNextPinName, importFzpz, alignShapes, calculateBoundingBox, 
  validatePart, extractPinsFromText, extractMetadataFromDatasheet
} from './utils';
import { generatePackage, generatePartWithAI, modifyPartWithAI, GeneratedContent } from './generators';

// --- STYLED COMPONENTS ---

const PanelHeader = ({ title, subtitle, icon: Icon }: { title: string, subtitle?: string, icon?: any }) => (
  <div className="px-4 py-3 border-b border-zinc-800 bg-zinc-900/50">
    <div className="flex items-center gap-2">
      {Icon && <Icon className="w-4 h-4 text-zinc-400" />}
      <h3 className="font-semibold text-sm text-zinc-100">{title}</h3>
    </div>
    {subtitle && <p className="text-[10px] text-zinc-500 uppercase tracking-wider mt-0.5 font-medium">{subtitle}</p>}
  </div>
);

const InputGroup = ({ label, children, error }: { label: string, children?: React.ReactNode, error?: string }) => (
  <div className="space-y-1">
    <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-tight ml-1">{label}</label>
    {children}
    {error && <p className="text-[10px] text-red-400 ml-1">{error}</p>}
  </div>
);

// --- DEBOUNCED INPUT COMPONENTS ---
const DebouncedInput = ({ value, onChange, type = "text", className = "", placeholder = "" }: { value: string | number, onChange: (v: string) => void, type?: string, className?: string, placeholder?: string }) => {
  const [localVal, setLocalVal] = useState(String(value));
  useEffect(() => setLocalVal(String(value)), [value]);
  const commit = () => { if (localVal !== String(value)) onChange(localVal); };
  return (
    <input type={type} className={`w-full bg-zinc-950 border border-zinc-800 rounded px-2 py-1.5 text-xs text-zinc-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/20 outline-none transition-all ${className}`} 
      value={localVal} placeholder={placeholder} onChange={e => setLocalVal(e.target.value)} onBlur={commit}
      onKeyDown={e => { if (e.key === 'Enter') commit(); }} 
    />
  );
};

const DebouncedNumber = ({ value, onChange, className = "" }: { value: number, onChange: (v: number) => void, className?: string }) => {
  const [localVal, setLocalVal] = useState(String(value));
  useEffect(() => setLocalVal(String(value)), [value]);
  const commit = () => { 
    const n = Number(localVal);
    if (!isNaN(n) && n !== value) onChange(n); 
    else setLocalVal(String(value));
  };
  return (
    <input type="number" className={`w-full bg-zinc-950 border border-zinc-800 rounded px-2 py-1.5 text-xs text-zinc-200 focus:border-indigo-500 outline-none transition-all ${className}`} 
      value={localVal} onChange={e => setLocalVal(e.target.value)} onBlur={commit}
      onKeyDown={e => { if (e.key === 'Enter') commit(); }} 
    />
  );
};

// --- INITIAL STATE ---
const initialMeta: PartMeta = {
  moduleId: generateUUID(),
  title: 'New Component',
  description: '',
  author: 'Unknown',
  version: '1.0.0',
  label: 'U',
  family: 'IC',
  tags: [],
  mountingType: 'through-hole',
  packageType: 'DIP',
  properties: {}
};

const defaultUIState: UIState = {
  activeView: 'breadboard',
  selection: [],
  pan: { x: 0, y: 0 },
  zoom: 1.5,
  gridEnabled: true,
  snapRadius: 8,
  activeTool: 'select',
  referenceImages: { breadboard: null, schematic: null, pcb: null },
  clipboard: undefined,
  showCommandPalette: false,
  validationIssues: [],
  modals: { generator: false, validation: false, aiImport: false, modify: false }
};

const initialState: AppState = {
  part: {
    meta: initialMeta,
    connectors: [],
    buses: [],
    views: {
      breadboard: { shapes: [{ id: generateUUID(), type: 'rect', x: 50, y: 50, w: 100, h: 100, fill: '#1a1a1a', stroke: '#333333', strokeWidth: 1, rx: 4, ry: 4, name: 'Package Body' }], enabled: true },
      schematic: { shapes: [], enabled: true },
      pcb: { shapes: [], enabled: true }
    }
  },
  ui: defaultUIState
};

function loadInitialState(): AppState {
  try {
    const saved = localStorage.getItem('fzpz-studio-save');
    if (saved) {
      const part = JSON.parse(saved);
      return { part, ui: defaultUIState };
    }
  } catch (e) { console.warn("Failed to load local save", e); }
  return initialState;
}

// --- REDUCER ---
type Action = 
  | { type: 'LOAD_PART', payload: AppState['part'] }
  | { type: 'SET_VIEW', payload: ViewType | 'metadata' }
  | { type: 'TOGGLE_VIEW_ENABLED', payload: ViewType }
  | { type: 'SET_TOOL', payload: UIState['activeTool'] }
  | { type: 'SET_PAN_ZOOM', payload: { pan: Point, zoom: number } }
  | { type: 'TOGGLE_GRID' }
  | { type: 'SET_SNAP_RADIUS', payload: number }
  | { type: 'SET_SELECTION', payload: SelectionRef[] }
  | { type: 'UPDATE_META', payload: Partial<PartMeta> }
  | { type: 'ADD_SHAPE', view: ViewType, payload: Shape }
  | { type: 'UPDATE_SHAPE', view: ViewType, id: string, payload: Partial<Shape> }
  | { type: 'DELETE_SHAPES', view: ViewType, ids: string[] }
  | { type: 'ALIGN_SHAPES', view: ViewType, alignment: any }
  | { type: 'GROUP_SELECTED', view: ViewType }
  | { type: 'UNGROUP_SELECTED', view: ViewType }
  | { type: 'ADD_CONNECTOR', payload: Connector }
  | { type: 'DELETE_CONNECTOR', id: string }
  | { type: 'UPDATE_CONNECTOR', id: string, payload: Partial<Connector> }
  | { type: 'UPDATE_PAD_SPEC', id: string, payload: Partial<PadSpec> }
  | { type: 'SET_REF_IMAGE', view: ViewType, payload: ReferenceImage | null }
  | { type: 'COPY_SELECTION', view: ViewType }
  | { type: 'PASTE_SELECTION', view: ViewType }
  | { type: 'TOGGLE_COMMAND_PALETTE' }
  | { type: 'SET_VALIDATION_ISSUES', payload: ValidationIssue[] }
  | { type: 'SET_MODAL_OPEN', modal: keyof UIState['modals'], isOpen: boolean }
  | { type: 'APPLY_GENERATOR', shapes: Record<ViewType, Shape[]>, connectors: Connector[] }
  | { type: 'REPLACE_CONTENT', shapes: Record<ViewType, Shape[]>, connectors: Connector[] }
  | { type: 'MERGE_EXTRACTED', meta: Partial<PartMeta>, connectors: Connector[] }
  | { type: 'UNDO' } | { type: 'REDO' };

type HistoryState = { past: AppState[], present: AppState, future: AppState[] };

function appReducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'LOAD_PART': return { ...state, part: action.payload, ui: { ...state.ui, selection: [] } };
    case 'SET_VIEW': return { ...state, ui: { ...state.ui, activeView: action.payload, selection: [] } };
    case 'TOGGLE_VIEW_ENABLED': {
      const v = state.part.views[action.payload];
      return { ...state, part: { ...state.part, views: { ...state.part.views, [action.payload]: { ...v, enabled: !v.enabled } } } };
    }
    case 'SET_TOOL': return { ...state, ui: { ...state.ui, activeTool: action.payload } };
    case 'SET_PAN_ZOOM': return { ...state, ui: { ...state.ui, pan: action.payload.pan, zoom: action.payload.zoom } };
    case 'TOGGLE_GRID': return { ...state, ui: { ...state.ui, gridEnabled: !state.ui.gridEnabled } };
    case 'SET_SNAP_RADIUS': return { ...state, ui: { ...state.ui, snapRadius: Math.max(0, action.payload) } };
    case 'SET_SELECTION': return { ...state, ui: { ...state.ui, selection: action.payload } };
    case 'UPDATE_META': return { ...state, part: { ...state.part, meta: { ...state.part.meta, ...action.payload } } };
    case 'ADD_SHAPE': {
      const v = state.part.views[action.view];
      return {
        ...state,
        part: { ...state.part, views: { ...state.part.views, [action.view]: { ...v, shapes: [...v.shapes, action.payload] } } },
        ui: { ...state.ui, selection: [{ type: 'shape', id: action.payload.id }] }
      };
    }
    case 'UPDATE_SHAPE': {
      const v = state.part.views[action.view];
      return {
        ...state,
        part: { ...state.part, views: { ...state.part.views, [action.view]: { ...v, shapes: v.shapes.map(s => s.id === action.id ? { ...s, ...action.payload } as Shape : s) } } }
      };
    }
    case 'DELETE_SHAPES': {
       const v = state.part.views[action.view];
       return {
           ...state,
           part: { ...state.part, views: { ...state.part.views, [action.view]: { ...v, shapes: v.shapes.filter(s => !action.ids.includes(s.id))}} },
           ui: { ...state.ui, selection: state.ui.selection.filter(sel => sel.type !== 'shape' || !action.ids.includes(sel.id)) }
       }
    }
    case 'ALIGN_SHAPES': {
       const v = state.part.views[action.view];
       const ids = state.ui.selection.filter(s => s.type === 'shape').map(s => s.id);
       return {
           ...state,
           part: { ...state.part, views: { ...state.part.views, [action.view]: { ...v, shapes: alignShapes(v.shapes, ids, action.alignment) } } }
       };
    }
    case 'GROUP_SELECTED': {
        const v = state.part.views[action.view];
        const selectedIds = state.ui.selection.filter(s => s.type === 'shape').map(s => s.id);
        if (selectedIds.length < 2) return state;
        const selectedShapes = v.shapes.filter(s => selectedIds.includes(s.id));
        let minX = Math.min(...selectedShapes.map(s => s.x)), minY = Math.min(...selectedShapes.map(s => s.y));
        const newGroup: GroupShape = { id: generateUUID(), type: 'group', x: minX, y: minY, children: selectedShapes.map(s => ({ ...s, x: s.x - minX, y: s.y - minY })), opacity: 1 };
        return {
            ...state,
            part: { ...state.part, views: { ...state.part.views, [action.view]: { ...v, shapes: [...v.shapes.filter(s => !selectedIds.includes(s.id)), newGroup] } } },
            ui: { ...state.ui, selection: [{ type: 'shape', id: newGroup.id }] }
        };
    }
    case 'UNGROUP_SELECTED': {
        const v = state.part.views[action.view];
        const selectedId = state.ui.selection[0]?.id;
        const group = v.shapes.find(s => s.id === selectedId);
        if (!group || group.type !== 'group') return state;
        const children = group.children.map(c => ({ ...c, x: c.x + group.x, y: c.y + group.y }));
        return {
            ...state,
            part: { ...state.part, views: { ...state.part.views, [action.view]: { ...v, shapes: [...v.shapes.filter(s => s.id !== selectedId), ...children] } } },
            ui: { ...state.ui, selection: children.map(c => ({ type: 'shape', id: c.id })) }
        };
    }
    case 'ADD_CONNECTOR': return { ...state, part: { ...state.part, connectors: [...state.part.connectors, action.payload] } };
    case 'DELETE_CONNECTOR': return {
        ...state,
        part: { ...state.part, connectors: state.part.connectors.filter(c => c.id !== action.id), buses: state.part.buses.map(b => ({ ...b, nodeMembers: b.nodeMembers.filter(nid => nid !== action.id) })) },
        ui: { ...state.ui, selection: [] }
    };
    case 'UPDATE_CONNECTOR': return { ...state, part: { ...state.part, connectors: state.part.connectors.map(c => c.id === action.id ? { ...c, ...action.payload } : c) } };
    case 'UPDATE_PAD_SPEC': return { ...state, part: { ...state.part, connectors: state.part.connectors.map(c => c.id === action.id ? { ...c, padSpec: { ...c.padSpec, ...action.payload } } : c) } };
    case 'SET_REF_IMAGE': return { ...state, ui: { ...state.ui, referenceImages: { ...state.ui.referenceImages, [action.view]: action.payload } } };
    case 'COPY_SELECTION': {
        const v = state.part.views[action.view];
        const ids = state.ui.selection.filter(s => s.type === 'shape').map(s => s.id);
        return { ...state, ui: { ...state.ui, clipboard: v.shapes.filter(s => ids.includes(s.id)) } };
    }
    case 'PASTE_SELECTION': {
        if (!state.ui.clipboard?.length) return state;
        const newShapes = state.ui.clipboard.map(s => ({ ...s, id: generateUUID(), x: s.x + 20, y: s.y + 20 } as Shape));
        const v = state.part.views[action.view];
        return {
            ...state,
            part: { ...state.part, views: { ...state.part.views, [action.view]: { ...v, shapes: [...v.shapes, ...newShapes] } } },
            ui: { ...state.ui, selection: newShapes.map(s => ({ type: 'shape', id: s.id })) }
        };
    }
    case 'TOGGLE_COMMAND_PALETTE': return { ...state, ui: { ...state.ui, showCommandPalette: !state.ui.showCommandPalette } };
    case 'SET_VALIDATION_ISSUES': return { ...state, ui: { ...state.ui, validationIssues: action.payload } };
    case 'SET_MODAL_OPEN': return { ...state, ui: { ...state.ui, modals: { ...state.ui.modals, [action.modal]: action.isOpen } } };
    case 'APPLY_GENERATOR': return {
        ...state,
        part: {
            ...state.part,
            connectors: [...state.part.connectors, ...action.connectors],
            views: {
                breadboard: { ...state.part.views.breadboard, shapes: [...state.part.views.breadboard.shapes, ...action.shapes.breadboard] },
                schematic: { ...state.part.views.schematic, shapes: [...state.part.views.schematic.shapes, ...action.shapes.schematic] },
                pcb: { ...state.part.views.pcb, shapes: [...state.part.views.pcb.shapes, ...action.shapes.pcb] },
            }
        },
        ui: { ...state.ui, modals: { ...state.ui.modals, generator: false } }
    };
    case 'REPLACE_CONTENT': return {
        ...state,
        part: {
            ...state.part,
            connectors: action.connectors,
            views: {
                breadboard: { ...state.part.views.breadboard, shapes: action.shapes.breadboard },
                schematic: { ...state.part.views.schematic, shapes: action.shapes.schematic },
                pcb: { ...state.part.views.pcb, shapes: action.shapes.pcb },
            }
        },
        ui: { ...state.ui, modals: { ...state.ui.modals, modify: false } }
    };
    case 'MERGE_EXTRACTED': return {
        ...state,
        part: {
            ...state.part,
            meta: { ...state.part.meta, ...action.meta },
            connectors: [...state.part.connectors, ...action.connectors]
        }
    };
    default: return state;
  }
}

function historyReducer(state: HistoryState, action: Action): HistoryState {
  const { past, present, future } = state;
  if (action.type === 'UNDO') {
    if (!past.length) return state;
    return { past: past.slice(0, -1), present: past[past.length - 1], future: [present, ...future] };
  }
  if (action.type === 'REDO') {
    if (!future.length) return state;
    return { past: [...past, present], present: future[0], future: future.slice(1) };
  }
  const newPresent = appReducer(present, action);
  const isTransient = ['SET_SELECTION', 'SET_PAN_ZOOM', 'SET_VIEW', 'SET_TOOL', 'COPY_SELECTION', 'TOGGLE_COMMAND_PALETTE', 'SET_VALIDATION_ISSUES', 'SET_MODAL_OPEN'].includes(action.type);
  if (isTransient || newPresent === present) return { ...state, present: newPresent };
  return { past: [...past, present], present: newPresent, future: [] };
}

// --- MODALS ---

const ValidationModal = ({ issues, onClose }: { issues: ValidationIssue[], onClose: () => void }) => (
  <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-6" onClick={onClose}>
    <div className="bg-zinc-950 border border-zinc-800 w-[560px] rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]" onClick={e => e.stopPropagation()}>
      <div className="p-4 border-b border-zinc-800 flex justify-between items-center bg-zinc-900/30">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-amber-500" />
          <h3 className="font-bold text-lg">Quality Assurance</h3>
        </div>
        <button onClick={onClose} className="p-1.5 hover:bg-zinc-800 rounded-lg transition-colors"><X className="w-5 h-5" /></button>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
        {issues.length === 0 ? <div className="text-center py-12 text-zinc-500">No issues found. Perfect design!</div> : issues.map((issue, i) => (
          <div key={i} className={`p-4 rounded-lg border flex gap-4 ${issue.level === 'error' ? 'bg-red-500/5 border-red-500/20 text-red-200' : 'bg-amber-500/5 border-amber-500/20 text-amber-200'}`}>
            {issue.level === 'error' ? <X className="w-5 h-5 shrink-0 text-red-500" /> : <AlertCircle className="w-5 h-5 shrink-0 text-amber-500" />}
            <div>
              <div className="font-semibold text-sm">{issue.message}</div>
              {issue.view && <div className="text-[10px] uppercase opacity-60 mt-1.5 font-bold tracking-widest">{issue.view}</div>}
            </div>
          </div>
        ))}
      </div>
      <div className="p-4 border-t border-zinc-800 bg-zinc-900/30 flex justify-end">
        <button onClick={onClose} className="px-6 py-2 bg-zinc-100 hover:bg-white text-zinc-950 rounded-lg text-sm font-bold transition-all shadow-lg shadow-white/5">Got it</button>
      </div>
    </div>
  </div>
);

const ModifyModal = ({ onClose, dispatch, currentContent }: { onClose: () => void, dispatch: React.Dispatch<Action>, currentContent: GeneratedContent }) => {
    const [prompt, setPrompt] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const handleModify = async () => {
        setLoading(true);
        setError('');
        try {
            const key = process.env.API_KEY || '';
            if (!key) throw new Error("API Key missing");
            const result = await modifyPartWithAI(currentContent, prompt, key);
            dispatch({ type: 'REPLACE_CONTENT', ...result });
            onClose();
        } catch (err) {
            setError(err instanceof Error ? err.message : "Modification failed");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-6" onClick={onClose}>
            <div className="bg-zinc-950 border border-zinc-800 w-[500px] rounded-xl shadow-2xl overflow-hidden" onClick={e => e.stopPropagation()}>
                <div className="p-4 border-b border-zinc-800 bg-zinc-900/30 flex justify-between items-center">
                    <h3 className="font-bold text-lg flex items-center gap-2"><Sparkles className="w-5 h-5 text-indigo-400" /> Fine-tune with AI</h3>
                    <button onClick={onClose} className="p-1.5 hover:bg-zinc-800 rounded-lg"><X className="w-5 h-5" /></button>
                </div>
                <div className="p-6 space-y-4">
                    <p className="text-xs text-zinc-400">Describe changes to apply to the current part (e.g., "Change pad shape to square", "Move USB port to the left").</p>
                    <textarea 
                        className="w-full h-32 bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-sm text-zinc-100 focus:border-indigo-500 outline-none resize-none placeholder-zinc-600"
                        placeholder="e.g. Increase pad size by 20%, Add a label '3.3V' next to pin 1..."
                        value={prompt}
                        onChange={e => setPrompt(e.target.value)}
                        onKeyDown={e => { if(e.key === 'Enter' && (e.metaKey || e.ctrlKey)) handleModify(); }}
                    />
                    {error && <div className="text-xs text-red-400 bg-red-500/10 p-2 rounded border border-red-500/20">{error}</div>}
                    <button 
                        disabled={loading || !prompt.trim()}
                        onClick={handleModify}
                        className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold transition-all shadow-lg shadow-indigo-600/20 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                        {loading ? <><Loader className="w-4 h-4 animate-spin" /> Modifying...</> : "Apply Changes"}
                    </button>
                </div>
            </div>
        </div>
    );
};

const GeneratorModal = ({ onClose, dispatch }: { onClose: () => void, dispatch: React.Dispatch<Action> }) => {
  const [tab, setTab] = useState<'ai' | 'manual'>('ai');
  const [loading, setLoading] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [error, setError] = useState('');
  const [attachment, setAttachment] = useState<{name: string, mimeType: string, data: string} | null>(null);
  
  const [opts, setOpts] = useState<GenOptions>({ 
      family: 'DIP', 
      pinCount: 8, 
      pitch_mm: 2.54, 
      rowSpacing_mm: 7.62, 
      padShape: 'round' 
  } as GenOptions);

  const isDiscrete = opts.family === 'Resistor' || opts.family === 'Capacitor';

  const handleAiGenerate = async () => {
      setLoading(true);
      setError('');
      try {
          const key = process.env.API_KEY || '';
          if (!key) throw new Error("API Key missing");
          
          const enhancedPrompt = prompt + " \n\nREQUIREMENTS:\n- Extremely high detail breadboard view (draw chips, capacitors, usb, text).\n- Accurate PCB footprint.\n- Correct pin grouping and spacing (e.g. Arduino header gaps).";
          
          const result = await generatePartWithAI(enhancedPrompt, key, attachment ? { mimeType: attachment.mimeType, data: attachment.data } : undefined);
          dispatch({ type: 'APPLY_GENERATOR', ...result });
          onClose();
      } catch (err) {
          setError(err instanceof Error ? err.message : "Generation failed");
      } finally {
          setLoading(false);
      }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onload = () => {
          const result = reader.result as string;
          const base64 = result.split(',')[1];
          setAttachment({
              name: file.name,
              mimeType: file.type,
              data: base64
          });
      };
      reader.readAsDataURL(file);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-6" onClick={onClose}>
      <div className="bg-zinc-950 border border-zinc-800 w-[500px] rounded-xl shadow-2xl overflow-hidden flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="flex border-b border-zinc-800">
            <button onClick={() => setTab('ai')} className={`flex-1 py-3 text-sm font-bold transition-all ${tab === 'ai' ? 'bg-zinc-900 text-indigo-400 border-b-2 border-indigo-500' : 'text-zinc-500 hover:bg-zinc-900/50'}`}>
                <div className="flex items-center justify-center gap-2"><Sparkles className="w-4 h-4" /> AI Wizard</div>
            </button>
            <button onClick={() => setTab('manual')} className={`flex-1 py-3 text-sm font-bold transition-all ${tab === 'manual' ? 'bg-zinc-900 text-zinc-100 border-b-2 border-zinc-700' : 'text-zinc-500 hover:bg-zinc-900/50'}`}>
                <div className="flex items-center justify-center gap-2"><Ruler className="w-4 h-4" /> Parametric</div>
            </button>
        </div>

        <div className="p-6 space-y-5">
          {tab === 'ai' ? (
              <div className="space-y-4">
                  <div className="p-4 bg-indigo-500/10 border border-indigo-500/20 rounded-xl">
                      <h4 className="text-indigo-300 font-bold text-sm mb-1 flex items-center gap-2"><Wand2 className="w-4 h-4" /> Magic Generator</h4>
                      <p className="text-xs text-indigo-200/70">Describe any component or attach a datasheet. The AI will calculate dimensions, pinouts, and geometries automatically.</p>
                  </div>
                  
                  <div>
                      <textarea 
                        className="w-full h-24 bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-sm text-zinc-100 focus:border-indigo-500 outline-none resize-none placeholder-zinc-600 mb-2"
                        placeholder="e.g. 'Arduino Pro Mini 3.3V', 'ESP32-WROOM Module', 'USB-C Breakout Board'..."
                        value={prompt}
                        onChange={e => setPrompt(e.target.value)}
                        onKeyDown={e => { if(e.key === 'Enter' && (e.metaKey || e.ctrlKey)) handleAiGenerate(); }}
                      />
                      
                      <div className="flex items-center justify-between">
                         <div className="flex gap-2">
                             <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider py-1">Examples:</span>
                             <button onClick={() => setPrompt("ESP32-WROOM-32E Module")} className="text-[10px] text-zinc-400 hover:text-indigo-400 bg-zinc-900 border border-zinc-800 px-2 py-0.5 rounded-md transition-colors">ESP32</button>
                             <button onClick={() => setPrompt("Rotary Encoder with Push Button")} className="text-[10px] text-zinc-400 hover:text-indigo-400 bg-zinc-900 border border-zinc-800 px-2 py-0.5 rounded-md transition-colors">Encoder</button>
                         </div>
                         <label className="cursor-pointer flex items-center gap-1.5 text-xs text-zinc-400 hover:text-indigo-400 transition-colors">
                             <Paperclip className="w-3.5 h-3.5" />
                             {attachment ? <span className="text-indigo-400 font-bold truncate max-w-[100px]">{attachment.name}</span> : "Attach Datasheet"}
                             <input type="file" className="hidden" accept="image/*,application/pdf" onChange={handleFileChange} />
                         </label>
                      </div>
                  </div>

                  {error && <div className="text-xs text-red-400 bg-red-500/10 p-2 rounded border border-red-500/20">{error}</div>}
                  <button 
                    disabled={loading || (!prompt.trim() && !attachment)}
                    onClick={handleAiGenerate}
                    className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white rounded-xl font-bold transition-all shadow-lg shadow-indigo-600/20 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {loading ? <><Loader className="w-4 h-4 animate-spin" /> Thinking...</> : <><Sparkles className="w-4 h-4" /> Generate Component</>}
                  </button>
              </div>
          ) : (
            <>
              {/* Manual parametric form omitted for brevity - same as before */}
              <InputGroup label="Family">
                <select className="w-full bg-zinc-900 border border-zinc-800 rounded-lg p-2 text-sm text-white outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all" value={opts.family} onChange={e => {
                    const fam = e.target.value as PackageFamily;
                    if (fam === 'Resistor' || fam === 'Capacitor') {
                        setOpts({ family: fam, packageCode: '0603', padShape: 'rect' } as any);
                    } else {
                        setOpts({ family: fam, pinCount: 8, pitch_mm: 2.54, rowSpacing_mm: 7.62, padShape: 'round' } as any);
                    }
                }}>
                  <option value="DIP">DIP (Dual Inline)</option>
                  <option value="SOIC">SOIC (Small Outline)</option>
                  <option value="QFP">QFP (Quad Flat)</option>
                  <option value="QFN">QFN (Quad Flat No-Lead)</option>
                  <option value="Header">Header (Pin Strip)</option>
                  <option disabled>──────────</option>
                  <option value="Resistor">Resistor (Chip)</option>
                  <option value="Capacitor">Capacitor (Chip)</option>
                </select>
              </InputGroup>
              <button onClick={() => { dispatch({ type: 'APPLY_GENERATOR', ...generatePackage(opts) }); onClose(); }} className="w-full py-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl font-bold transition-all shadow-lg shadow-zinc-900/20 active:scale-[0.98]">
                Generate Parametric
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

// --- CORE COMPONENTS ---

interface NavTabProps {
  id: string;
  active: boolean;
  onClick: () => void;
  enabled?: boolean;
  onToggleEnabled?: () => void;
}

const NavTab: React.FC<NavTabProps> = ({ id, active, onClick, enabled, onToggleEnabled }) => (
  <div className={`group flex items-center h-full px-4 border-b-2 transition-all cursor-pointer select-none ${active ? 'border-indigo-500 bg-zinc-800/40 text-white' : 'border-transparent text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800/20'}`} onClick={onClick}>
    <span className="text-xs font-bold uppercase tracking-widest">{id}</span>
    {onToggleEnabled && (
      <button onClick={e => { e.stopPropagation(); onToggleEnabled(); }} className={`ml-2 p-1 rounded-md transition-all opacity-0 group-hover:opacity-100 ${enabled ? 'text-green-500' : 'text-zinc-700 hover:text-zinc-500'}`} title={enabled ? "View Enabled" : "View Disabled"}>
        {enabled ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
      </button>
    )}
  </div>
);

const ToolbarButton = ({ icon: Icon, label, active, onClick, shortcut }: { icon: any, label: string, active?: boolean, onClick: () => void, shortcut?: string }) => (
  <button onClick={onClick} title={`${label} (${shortcut || ''})`} className={`w-10 h-10 flex items-center justify-center rounded-xl transition-all relative group ${active ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30' : 'text-zinc-500 hover:text-zinc-200 hover:bg-zinc-800'}`}>
    <Icon className="w-5 h-5" />
    {!active && <div className="absolute left-12 px-2 py-1 bg-zinc-950 text-white text-[10px] font-bold rounded shadow-xl border border-zinc-800 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50 pointer-events-none">{label}</div>}
  </button>
);

const InspectorField = ({ label, children, horizontal }: { label: string, children?: React.ReactNode, horizontal?: boolean }) => (
  <div className={`flex ${horizontal ? 'flex-row items-center justify-between gap-4' : 'flex-col gap-1.5'}`}>
    <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-0.5">{label}</label>
    <div className={horizontal ? 'w-1/2' : 'w-full'}>{children}</div>
  </div>
);

const ShapeProps = ({ shape, view, dispatch }: { shape: Shape, view: ViewType, dispatch: React.Dispatch<Action> }) => {
  const update = (payload: Partial<Shape>) => dispatch({ type: 'UPDATE_SHAPE', view, id: shape.id, payload });
  
  const validation = useMemo(() => {
    const issues = [];
    if (shape.type === 'rect' && (shape.w < 0 || shape.h < 0)) issues.push('W/H must be positive');
    if (shape.type === 'circle' && shape.r < 0) issues.push('Radius must be positive');
    if (shape.type === 'text' && shape.fontSize < 0) issues.push('Font size must be positive');
    return issues;
  }, [shape]);

  return (
    <div className="space-y-4">
      {validation.length > 0 && (
        <div className="bg-red-500/10 border border-red-500/20 p-2 rounded-lg flex items-center gap-2 mb-2">
          <AlertCircle className="w-3.5 h-3.5 text-red-500 shrink-0" />
          <span className="text-[10px] font-bold text-red-400">{validation[0]}</span>
        </div>
      )}
      
      <div className="grid grid-cols-2 gap-3">
        <InspectorField label="X Pos"><DebouncedNumber value={shape.x} onChange={v => update({x: v})} /></InspectorField>
        <InspectorField label="Y Pos"><DebouncedNumber value={shape.y} onChange={v => update({y: v})} /></InspectorField>
        
        {shape.type === 'rect' && (
          <>
            <InspectorField label="Width"><DebouncedNumber value={shape.w} onChange={v => update({w: v})} /></InspectorField>
            <InspectorField label="Height"><DebouncedNumber value={shape.h} onChange={v => update({h: v})} /></InspectorField>
            <InspectorField label="Corner R"><DebouncedNumber value={shape.rx || 0} onChange={v => update({rx: v, ry: v})} /></InspectorField>
          </>
        )}
        
        {shape.type === 'circle' && (
          <InspectorField label="Radius"><DebouncedNumber value={shape.r} onChange={v => update({r: v})} /></InspectorField>
        )}
        
        {shape.type === 'text' && (
          <div className="col-span-2 space-y-3">
            <InspectorField label="Content"><DebouncedInput value={shape.content} onChange={v => update({content: v})} /></InspectorField>
            <div className="grid grid-cols-2 gap-3">
              <InspectorField label="Font Size"><DebouncedNumber value={shape.fontSize} onChange={v => update({fontSize: v})} /></InspectorField>
              <InspectorField label="Font Family"><DebouncedInput value={shape.fontFamily || 'OCRA'} onChange={v => update({fontFamily: v})} /></InspectorField>
            </div>
          </div>
        )}
      </div>

      <div className="pt-2">
        <InspectorField label="Fill Color">
          <div className="flex gap-2">
            <input type="color" className="w-10 h-8 rounded border border-zinc-800 bg-transparent cursor-pointer overflow-hidden p-0" value={shape.fill?.startsWith('#') ? shape.fill : '#ffffff'} onChange={e => update({fill: e.target.value})} />
            <DebouncedInput value={shape.fill || 'none'} onChange={v => update({fill: v})} />
          </div>
        </InspectorField>
      </div>
      
      <div className="pt-2">
        <InspectorField label="Stroke Color">
          <div className="flex gap-2">
            <input type="color" className="w-10 h-8 rounded border border-zinc-800 bg-transparent cursor-pointer overflow-hidden p-0" value={shape.stroke?.startsWith('#') ? shape.stroke : '#000000'} onChange={e => update({stroke: e.target.value})} />
            <DebouncedInput value={shape.stroke || 'none'} onChange={v => update({stroke: v})} />
          </div>
        </InspectorField>
      </div>

      <InspectorField label="Stroke Width"><DebouncedNumber value={shape.strokeWidth || 0} onChange={v => update({strokeWidth: v})} /></InspectorField>
      <InspectorField label="Opacity">
        <input type="range" min="0" max="1" step="0.1" value={shape.opacity ?? 1} className="w-full accent-indigo-600" onChange={e => update({opacity: parseFloat(e.target.value)})} />
      </InspectorField>
    </div>
  );
};

export default function App() {
  const [history, dispatch] = useReducer(historyReducer, { past: [], present: loadInitialState(), future: [] });
  const state = history.present;
  const { ui, part } = state;
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'error'>('saved');
  const [mouseWorld, setMouseWorld] = useState<Point>({ x: 0, y: 0 });
  const svgRef = useRef<SVGSVGElement>(null);
  const [panning, setPanning] = useState(false);
  const [lastMouse, setLastMouse] = useState<Point>({ x: 0, y: 0 });
  const [apiKey, setApiKey] = useState(process.env.API_KEY || '');
  const [extracting, setExtracting] = useState(false);
  
  // Dragging State
  const [dragging, setDragging] = useState(false);
  const dragStateRef = useRef<{
      startMouse: Point,
      originalPositions: Map<string, Point>
  }>({ startMouse: {x:0,y:0}, originalPositions: new Map() });

  // Auto-save logic
  useEffect(() => {
    setSaveStatus('saving');
    const t = setTimeout(() => {
      try { localStorage.setItem('fzpz-studio-save', JSON.stringify(part)); setSaveStatus('saved'); }
      catch (e) { setSaveStatus('error'); }
    }, 1000);
    return () => clearTimeout(t);
  }, [part]);

  // Global Keys
  useEffect(() => {
    const handle = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if ((e.ctrlKey || e.metaKey) && e.key === 'z') { e.preventDefault(); dispatch({ type: 'UNDO' }); }
      if ((e.ctrlKey || e.metaKey) && e.key === 'y') { e.preventDefault(); dispatch({ type: 'REDO' }); }
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); dispatch({ type: 'TOGGLE_COMMAND_PALETTE' }); }
      
      // Keyboard Movement
      if (ui.activeView !== 'metadata' && ui.selection.length > 0 && ['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)) {
         e.preventDefault();
         const step = e.shiftKey ? 100 : (e.altKey ? 1 : 10);
         let dx = 0, dy = 0;
         if(e.key === 'ArrowUp') dy = -step;
         if(e.key === 'ArrowDown') dy = step;
         if(e.key === 'ArrowLeft') dx = -step;
         if(e.key === 'ArrowRight') dx = step;
         
         // Apply to all selected items
         ui.selection.forEach(sel => {
            if (sel.type === 'shape') {
                const s = part.views[ui.activeView as ViewType].shapes.find(x => x.id === sel.id);
                if(s) dispatch({ type: 'UPDATE_SHAPE', view: ui.activeView as ViewType, id: s.id, payload: { x: s.x + dx, y: s.y + dy }});
            } else if (sel.type === 'connector') {
                 const c = part.connectors.find(x => x.id === sel.id);
                 if (c) {
                    const viewKey = `${ui.activeView}Terminal` as keyof Connector;
                    const pos = c[viewKey] as Point;
                    if(pos) dispatch({ type: 'UPDATE_CONNECTOR', id: c.id, payload: { [viewKey]: { x: pos.x + dx, y: pos.y + dy } } });
                 }
            }
         });
      }
    };
    window.addEventListener('keydown', handle);
    return () => window.removeEventListener('keydown', handle);
  }, [ui.activeView, ui.selection, part]);

  const handleDatasheetUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      
      const key = process.env.API_KEY || '';
      if (!key) { alert("API Key missing"); return; }

      setExtracting(true);
      try {
          const reader = new FileReader();
          reader.onload = async () => {
              const result = reader.result as string;
              const base64 = result.split(',')[1];
              const extracted = await extractMetadataFromDatasheet({ mimeType: file.type, data: base64 }, key);
              dispatch({ type: 'MERGE_EXTRACTED', meta: extracted.meta, connectors: extracted.connectors });
          };
          reader.readAsDataURL(file);
      } catch (err) {
          alert("Extraction failed: " + (err instanceof Error ? err.message : "Unknown error"));
      } finally {
          setExtracting(false);
      }
      e.target.value = ''; // Reset
  };

  const handleCanvasInteraction = (e: React.MouseEvent) => {
    if (!svgRef.current || ui.activeView === 'metadata') return;
    const rect = svgRef.current.getBoundingClientRect();
    const world = screenToWorld(e.clientX - rect.left, e.clientY - rect.top, ui.pan, ui.zoom);
    
    if (e.type === 'mousedown') {
      setLastMouse({ x: e.clientX, y: e.clientY });
      
      // Right/Middle click Pan
      if (e.button === 1 || (e.button === 0 && e.altKey)) {
          setPanning(true);
          return;
      }
      
      if (ui.activeTool === 'select' && e.button === 0) {
          // Check hit detection manually or rely on bubble up from elements?
          // Bubbling handles 'SET_SELECTION'. We check if we clicked an existing selection to start drag
          // We need to know if the target was a shape/connector
          const isShapeOrConn = (e.target as Element).closest('[data-drag-id]');
          if (isShapeOrConn) {
             setDragging(true);
             dragStateRef.current.startMouse = world;
             // Store initial positions of all selected items
             dragStateRef.current.originalPositions.clear();
             ui.selection.forEach(sel => {
                 if (sel.type === 'shape') {
                     const s = part.views[ui.activeView as ViewType].shapes.find(x => x.id === sel.id);
                     if(s) dragStateRef.current.originalPositions.set(sel.id, {x: s.x, y: s.y});
                 } else {
                     const c = part.connectors.find(x => x.id === sel.id);
                     if(c) {
                        const pos = c[`${ui.activeView}Terminal` as keyof Connector] as Point;
                        if(pos) dragStateRef.current.originalPositions.set(sel.id, {x: pos.x, y: pos.y});
                     }
                 }
             });
             return;
          }
      }

      // Tools
      if (['rect', 'circle', 'text', 'pin'].includes(ui.activeTool)) {
        const id = generateUUID();
        if (ui.activeTool === 'rect') dispatch({ type: 'ADD_SHAPE', view: ui.activeView as ViewType, payload: { id, type: 'rect', x: world.x, y: world.y, w: 50, h: 50, fill: '#3f3f46', stroke: '#52525b', strokeWidth: 1 } });
        else if (ui.activeTool === 'circle') dispatch({ type: 'ADD_SHAPE', view: ui.activeView as ViewType, payload: { id, type: 'circle', x: world.x, y: world.y, r: 25, fill: '#3f3f46', stroke: '#52525b', strokeWidth: 1 } });
        else if (ui.activeTool === 'text') dispatch({ type: 'ADD_SHAPE', view: ui.activeView as ViewType, payload: { id, type: 'text', x: world.x, y: world.y, content: 'Label', fontSize: 14, fill: '#f4f4f5' } });
        else if (ui.activeTool === 'pin') {
           const connId = generateUUID();
           const name = generateNextPinName(part.connectors);
           dispatch({ type: 'ADD_CONNECTOR', payload: { id: connId, name, type: 'male', shapeIds: {}, padSpec: { padShape: 'round', padWidth: 2, padHeight: 2, holeDiameter: 0.8 }, [`${ui.activeView}Terminal`]: { x: world.x, y: world.y } } });
        }
        dispatch({ type: 'SET_TOOL', payload: 'select' });
      }
    } else if (e.type === 'mousemove') {
      setMouseWorld(world);
      
      if (dragging && ui.activeTool === 'select') {
          // Calculate Delta
          let dx = world.x - dragStateRef.current.startMouse.x;
          let dy = world.y - dragStateRef.current.startMouse.y;
          
          // Apply Snap to delta if grid enabled? Or snap final pos? 
          // Usually easier to snap the delta or snap the resulting position of the primary object.
          // Let's snap the delta to nearest snapRadius
          if (ui.gridEnabled) {
              const snap = ui.snapRadius || 1;
              dx = Math.round(dx / snap) * snap;
              dy = Math.round(dy / snap) * snap;
          }

          ui.selection.forEach(sel => {
              const original = dragStateRef.current.originalPositions.get(sel.id);
              if (!original) return;
              
              if (sel.type === 'shape') {
                  dispatch({ type: 'UPDATE_SHAPE', view: ui.activeView as ViewType, id: sel.id, payload: { x: original.x + dx, y: original.y + dy } });
              } else if (sel.type === 'connector') {
                  dispatch({ type: 'UPDATE_CONNECTOR', id: sel.id, payload: { [`${ui.activeView}Terminal`]: { x: original.x + dx, y: original.y + dy } } });
              }
          });
      }
      else if (panning) {
        dispatch({ type: 'SET_PAN_ZOOM', payload: { pan: { x: ui.pan.x + (e.clientX - lastMouse.x), y: ui.pan.y + (e.clientY - lastMouse.y) }, zoom: ui.zoom } });
        setLastMouse({ x: e.clientX, y: e.clientY });
      }
    } else if (e.type === 'mouseup' || e.type === 'mouseleave') {
      setPanning(false);
      setDragging(false);
    }
  };

  const handleWheel = (e: React.WheelEvent) => {
    const scale = e.deltaY > 0 ? 0.95 : 1.05;
    dispatch({ type: 'SET_PAN_ZOOM', payload: { pan: ui.pan, zoom: Math.max(0.1, Math.min(10, ui.zoom * scale)) } });
  };

  const selectedRef = ui.selection[0];
  const selectedShape = selectedRef?.type === 'shape' ? part.views[ui.activeView as ViewType]?.shapes.find(s => s.id === selectedRef.id) : null;
  const selectedConn = selectedRef?.type === 'connector' ? part.connectors.find(c => c.id === selectedRef.id) : null;

  return (
    <div className="flex flex-col h-full overflow-hidden select-none bg-zinc-950">
      {/* --- TOP BAR --- */}
      <div className="h-14 border-b border-zinc-800 flex items-center justify-between px-6 bg-zinc-900 shadow-xl z-50">
        <div className="flex items-center gap-6 h-full">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-lg shadow-indigo-600/20">
              <Box className="w-5 h-5" />
            </div>
            <div>
              <h1 className="font-bold text-sm tracking-tight leading-none text-zinc-100">FZPZ Studio</h1>
              <p className="text-[10px] text-zinc-500 font-mono mt-1">v1.2 // STABLE</p>
            </div>
          </div>
          
          <nav className="flex h-full ml-4">
            <NavTab id="Metadata" active={ui.activeView === 'metadata'} onClick={() => dispatch({ type: 'SET_VIEW', payload: 'metadata' })} />
            {(['breadboard', 'schematic', 'pcb'] as ViewType[]).map(v => (
              <NavTab key={v} id={v} active={ui.activeView === v} onClick={() => dispatch({ type: 'SET_VIEW', payload: v })} enabled={part.views[v].enabled} onToggleEnabled={() => dispatch({ type: 'TOGGLE_VIEW_ENABLED', payload: v })} />
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 mr-2 bg-zinc-800/50 p-1 rounded-lg border border-zinc-800">
            <button disabled={!history.past.length} onClick={() => dispatch({ type: 'UNDO' })} className="p-1.5 rounded-md hover:bg-zinc-700 disabled:opacity-30 transition-colors"><Undo2 className="w-4 h-4" /></button>
            <button disabled={!history.future.length} onClick={() => dispatch({ type: 'REDO' })} className="p-1.5 rounded-md hover:bg-zinc-700 disabled:opacity-30 transition-colors"><Redo2 className="w-4 h-4" /></button>
          </div>

          <button onClick={() => dispatch({ type: 'SET_MODAL_OPEN', modal: 'modify', isOpen: true })} className="flex items-center gap-2 px-3 py-2 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 text-xs font-bold rounded-lg border border-indigo-500/30 transition-all active:scale-95"><Sparkles className="w-4 h-4" /> AI Modify</button>
          
          <button onClick={() => dispatch({ type: 'SET_MODAL_OPEN', modal: 'generator', isOpen: true })} className="flex items-center gap-2 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-100 text-xs font-bold rounded-lg border border-zinc-700 transition-all active:scale-95"><Box className="w-4 h-4" /> Wizard</button>
          <label className="flex items-center gap-2 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-100 text-xs font-bold rounded-lg border border-zinc-700 transition-all cursor-pointer"><Upload className="w-4 h-4" /> Import<input type="file" className="hidden" accept=".fzpz" onChange={async e => { if (e.target.files?.[0]) { const p = await importFzpz(e.target.files[0]); if (p) dispatch({ type: 'LOAD_PART', payload: p }); } e.target.value = ''; }} /></label>
          <button onClick={() => { try { exportFzpz(part); } catch(e) { dispatch({ type: 'SET_VALIDATION_ISSUES', payload: validatePart(part) }); dispatch({ type: 'SET_MODAL_OPEN', modal: 'validation', isOpen: true }); } }} className="flex items-center gap-2 px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg shadow-lg shadow-indigo-600/20 border border-indigo-500 transition-all active:scale-95"><Download className="w-4 h-4" /> Export</button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden relative">
        {/* --- LEFT TOOLBAR --- */}
        <div className="w-14 bg-zinc-900 border-r border-zinc-800 flex flex-col items-center py-4 gap-4 shadow-2xl z-40">
          <div className="flex flex-col gap-1.5">
            <ToolbarButton icon={MousePointer2} label="Select" active={ui.activeTool === 'select'} onClick={() => dispatch({ type: 'SET_TOOL', payload: 'select' })} shortcut="V" />
            <ToolbarButton icon={Square} label="Rectangle" active={ui.activeTool === 'rect'} onClick={() => dispatch({ type: 'SET_TOOL', payload: 'rect' })} shortcut="R" />
            <ToolbarButton icon={CircleIcon} label="Circle" active={ui.activeTool === 'circle'} onClick={() => dispatch({ type: 'SET_TOOL', payload: 'circle' })} shortcut="C" />
            <ToolbarButton icon={Type} label="Text" active={ui.activeTool === 'text'} onClick={() => dispatch({ type: 'SET_TOOL', payload: 'text' })} shortcut="T" />
            <ToolbarButton icon={Plug} label="Pin" active={ui.activeTool === 'pin'} onClick={() => dispatch({ type: 'SET_TOOL', payload: 'pin' })} shortcut="P" />
            <ToolbarButton icon={Ruler} label="Measure" active={ui.activeTool === 'measure'} onClick={() => dispatch({ type: 'SET_TOOL', payload: 'measure' })} shortcut="M" />
          </div>
          
          {ui.activeView !== 'metadata' && (
            <>
              <div className="w-8 h-px bg-zinc-800" />
              <div className="flex flex-col gap-1">
                <ToolbarButton icon={AlignLeft} label="Align Left" onClick={() => dispatch({ type: 'ALIGN_SHAPES', view: ui.activeView as ViewType, alignment: 'left' })} />
                <ToolbarButton icon={AlignHorizontalJustifyCenter} label="Align Center H" onClick={() => dispatch({ type: 'ALIGN_SHAPES', view: ui.activeView as ViewType, alignment: 'center-h' })} />
                <ToolbarButton icon={AlignRight} label="Align Right" onClick={() => dispatch({ type: 'ALIGN_SHAPES', view: ui.activeView as ViewType, alignment: 'right' })} />
                <div className="h-2" />
                <ToolbarButton icon={AlignVerticalJustifyStart} label="Align Top" onClick={() => dispatch({ type: 'ALIGN_SHAPES', view: ui.activeView as ViewType, alignment: 'top' })} />
                <ToolbarButton icon={AlignVerticalJustifyCenter} label="Align Center V" onClick={() => dispatch({ type: 'ALIGN_SHAPES', view: ui.activeView as ViewType, alignment: 'center-v' })} />
                <ToolbarButton icon={AlignVerticalJustifyEnd} label="Align Bottom" onClick={() => dispatch({ type: 'ALIGN_SHAPES', view: ui.activeView as ViewType, alignment: 'bottom' })} />
                <div className="h-2" />
                <ToolbarButton icon={AlignHorizontalDistributeCenter} label="Distribute H" onClick={() => dispatch({ type: 'ALIGN_SHAPES', view: ui.activeView as ViewType, alignment: 'dist-h' })} />
                <ToolbarButton icon={AlignVerticalDistributeCenter} label="Distribute V" onClick={() => dispatch({ type: 'ALIGN_SHAPES', view: ui.activeView as ViewType, alignment: 'dist-v' })} />
              </div>
            </>
          )}
        </div>

        {/* --- MAIN AREA --- */}
        <main className="flex-1 overflow-hidden flex relative bg-[#09090b]">
          {ui.activeView === 'metadata' ? (
            <div className="flex-1 overflow-y-auto p-12 bg-zinc-950 flex justify-center custom-scrollbar">
              <div className="max-w-2xl w-full space-y-8 animate-in fade-in duration-500">
                <div className="border-b border-zinc-800 pb-6 flex justify-between items-end">
                  <div>
                    <h2 className="text-3xl font-black text-white tracking-tight">Component Meta</h2>
                    <p className="text-zinc-500 text-sm mt-1">Configure global FZP definition properties.</p>
                  </div>
                </div>

                {/* AI Extraction Banner */}
                <div className="p-5 bg-gradient-to-r from-indigo-900/20 to-purple-900/20 border border-indigo-500/30 rounded-xl flex flex-col md:flex-row gap-4 items-center justify-between">
                    <div>
                        <h3 className="text-indigo-300 font-bold flex items-center gap-2"><Sparkles className="w-4 h-4" /> Smart Datasheet Extraction</h3>
                        <p className="text-xs text-indigo-200/60 mt-1 max-w-sm">Upload a PDF or Image datasheet to automatically extract metadata and pinout information using Gemini Flash.</p>
                    </div>
                    <label className={`flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-lg shadow-indigo-600/20 ${extracting ? 'opacity-50 pointer-events-none' : ''}`}>
                        {extracting ? <Loader className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                        {extracting ? 'Analyzing...' : 'Upload Datasheet'}
                        <input type="file" className="hidden" accept="application/pdf,image/*" onChange={handleDatasheetUpload} />
                    </label>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <InputGroup label="Part Title"><DebouncedInput value={part.meta.title} onChange={v => dispatch({type: 'UPDATE_META', payload: {title: v}})} placeholder="e.g. Arduino Nano" /></InputGroup>
                  <InputGroup label="Family"><DebouncedInput value={part.meta.family} onChange={v => dispatch({type: 'UPDATE_META', payload: {family: v}})} placeholder="Microcontroller" /></InputGroup>

                  <InputGroup label="Manufacturer"><DebouncedInput value={part.meta.manufacturer || ''} onChange={v => dispatch({type: 'UPDATE_META', payload: {manufacturer: v}})} placeholder="e.g. Microchip" /></InputGroup>
                  <InputGroup label="Part Number (MPN)"><DebouncedInput value={part.meta.mpn || ''} onChange={v => dispatch({type: 'UPDATE_META', payload: {mpn: v}})} placeholder="e.g. ATmega328P" /></InputGroup>
                  
                  {/* Datasheet URL Field */}
                  <div className="md:col-span-2">
                      <InputGroup label="Datasheet URL">
                          <div className="relative">
                            <Link className="absolute left-3 top-2 w-3.5 h-3.5 text-zinc-500" />
                            <DebouncedInput className="pl-8" value={part.meta.datasheetUrl || ''} onChange={v => dispatch({type: 'UPDATE_META', payload: {datasheetUrl: v}})} placeholder="https://example.com/datasheet.pdf" />
                          </div>
                      </InputGroup>
                  </div>

                  <div className="md:col-span-2">
                    <div className="flex justify-between items-center mb-1">
                       <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-tight ml-1">Description</label>
                       <button onClick={async () => { if (!apiKey) return alert("API Key missing"); const d = await suggestDescription(part.meta.title, apiKey); dispatch({type: 'UPDATE_META', payload: {description: d}}); }} className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300 transition-colors uppercase flex items-center gap-1"><Sparkles className="w-3 h-3" /> Auto-Suggest</button>
                    </div>
                    <textarea className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-4 text-sm text-zinc-200 focus:border-indigo-500 outline-none h-32 resize-none transition-all" value={part.meta.description} onChange={e => dispatch({type: 'UPDATE_META', payload: {description: e.target.value}})} placeholder="Brief description of the component..." />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <InputGroup label="RefDes Label"><DebouncedInput value={part.meta.label} onChange={v => dispatch({type: 'UPDATE_META', payload: {label: v.toUpperCase()}})} placeholder="U" /></InputGroup>
                    <InputGroup label="Version"><DebouncedInput value={part.meta.version} onChange={v => dispatch({type: 'UPDATE_META', payload: {version: v}})} /></InputGroup>
                  </div>
                  <InputGroup label="Author"><DebouncedInput value={part.meta.author} onChange={v => dispatch({type: 'UPDATE_META', payload: {author: v}})} /></InputGroup>
                </div>

                <div className="pt-8 border-t border-zinc-900">
                  <h3 className="text-zinc-400 font-bold text-xs uppercase tracking-widest mb-4 flex items-center gap-2"><Search className="w-3 h-3" /> Search Tags</h3>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {part.meta.tags.map(t => (
                      <span key={t} className="px-3 py-1 bg-zinc-900 border border-zinc-800 rounded-full text-xs text-zinc-300 flex items-center gap-2 group transition-all hover:border-zinc-700">
                        {t}
                        <button onClick={() => dispatch({type: 'UPDATE_META', payload: {tags: part.meta.tags.filter(x => x !== t)}})} className="hover:text-red-400"><X className="w-3 h-3" /></button>
                      </span>
                    ))}
                  </div>
                  <input type="text" className="bg-transparent border-b border-zinc-800 text-sm text-zinc-100 py-1.5 px-1 outline-none focus:border-indigo-500 w-64 placeholder-zinc-700" placeholder="Type tag and press Enter..." onKeyDown={e => { if (e.key === 'Enter') { const t = e.currentTarget.value.trim().toLowerCase(); if (t && !part.meta.tags.includes(t)) dispatch({type: 'UPDATE_META', payload: {tags: [...part.meta.tags, t]}}); e.currentTarget.value = ''; } }} />
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 h-full relative group" onMouseDown={handleCanvasInteraction} onMouseMove={handleCanvasInteraction} onMouseUp={handleCanvasInteraction} onMouseLeave={handleCanvasInteraction} onWheel={handleWheel}>
              <svg ref={svgRef} className="w-full h-full block bg-[#09090b] touch-none">
                <defs>
                   <pattern id="grid-dot" width={20 * ui.zoom} height={20 * ui.zoom} patternUnits="userSpaceOnUse">
                      <circle cx={1 * ui.zoom} cy={1 * ui.zoom} r={0.8 * ui.zoom} fill="#27272a" />
                   </pattern>
                </defs>
                {ui.gridEnabled && <rect width="100%" height="100%" fill="url(#grid-dot)" />}
                
                <g transform={`translate(${ui.pan.x}, ${ui.pan.y}) scale(${ui.zoom})`}>
                  {ui.referenceImages[ui.activeView as ViewType] && (
                    <image href={ui.referenceImages[ui.activeView as ViewType]!.dataUrl} x={ui.referenceImages[ui.activeView as ViewType]!.x} y={ui.referenceImages[ui.activeView as ViewType]!.y} width={ui.referenceImages[ui.activeView as ViewType]!.width} height={ui.referenceImages[ui.activeView as ViewType]!.height} opacity={ui.referenceImages[ui.activeView as ViewType]!.opacity} style={{pointerEvents: 'none'}} />
                  )}
                  
                  {/* Snap Indicator */}
                  <circle cx={mouseWorld.x} cy={mouseWorld.y} r={ui.snapRadius} fill="rgba(255, 255, 0, 0.1)" stroke="yellow" strokeWidth={1/ui.zoom} opacity={0.5} pointerEvents="none" />
                  
                  {part.views[ui.activeView as ViewType]?.shapes.map(s => {
                    const isSel = ui.selection.some(r => r.id === s.id);
                    const props = { 
                      onMouseDown: (e: any) => { e.stopPropagation(); dispatch({ type: 'SET_SELECTION', payload: [{ type: 'shape', id: s.id }] }); },
                      fill: s.fill, stroke: isSel ? '#6366f1' : s.stroke, strokeWidth: isSel ? Math.max(2/ui.zoom, (s.strokeWidth || 1)) : s.strokeWidth, opacity: s.opacity,
                      style: { cursor: panning ? 'grabbing' : 'move' },
                      'data-drag-id': s.id
                    };
                    if (s.type === 'rect') return <rect key={s.id} x={s.x} y={s.y} width={s.w} height={s.h} rx={s.rx} ry={s.ry} {...props} />;
                    if (s.type === 'circle') return <circle key={s.id} cx={s.x} cy={s.y} r={s.r} {...props} />;
                    if (s.type === 'text') return <text key={s.id} x={s.x} y={s.y} fontSize={s.fontSize} fontFamily={s.fontFamily || 'OCRA'} {...props} fill={s.fill} stroke="none">{s.content}</text>;
                    return null;
                  })}
                  
                  {part.connectors.map(c => {
                    const term = c[`${ui.activeView}Terminal` as keyof Connector] as Point;
                    if (!term) return null;
                    const isSel = ui.selection.some(r => r.id === c.id);
                    return (
                      <g key={c.id} transform={`translate(${term.x}, ${term.y})`} onMouseDown={e => { e.stopPropagation(); dispatch({ type: 'SET_SELECTION', payload: [{ type: 'connector', id: c.id }] }); }} style={{ cursor: 'move' }} data-drag-id={c.id}>
                        <circle r={isSel ? 6 : 4} fill={isSel ? '#6366f1' : '#f87171'} stroke="white" strokeWidth={isSel ? 2 : 1} />
                        {ui.zoom > 1.2 && <text y={-8} fontSize={6} fill="white" textAnchor="middle" className="font-bold pointer-events-none drop-shadow-md">{c.name}</text>}
                      </g>
                    );
                  })}
                </g>
              </svg>
              
              <div className="absolute bottom-6 right-6 flex items-center gap-3 bg-zinc-900/80 backdrop-blur-md border border-zinc-800 p-2 rounded-xl shadow-2xl transition-all hover:bg-zinc-900">
                <button onClick={() => dispatch({ type: 'SET_PAN_ZOOM', payload: { pan: ui.pan, zoom: Math.max(0.1, ui.zoom * 0.8) } })} className="p-1.5 hover:bg-zinc-800 rounded-lg"><X className="w-3.5 h-3.5 rotate-45" /></button>
                <span className="text-[10px] font-mono font-bold text-zinc-400 w-12 text-center">{(ui.zoom * 100).toFixed(0)}%</span>
                <button onClick={() => dispatch({ type: 'SET_PAN_ZOOM', payload: { pan: ui.pan, zoom: Math.min(10, ui.zoom * 1.2) } })} className="p-1.5 hover:bg-zinc-800 rounded-lg"><X className="w-3.5 h-3.5" /></button>
              </div>
            </div>
          )}

          {/* --- RIGHT INSPECTOR --- */}
          <aside className="w-80 border-l border-zinc-800 bg-zinc-900 overflow-y-auto flex flex-col z-40 custom-scrollbar">
            {ui.activeView === 'metadata' ? (
              <div className="p-6 text-center space-y-4 animate-in slide-in-from-right duration-300">
                <div className="w-16 h-16 bg-zinc-800 rounded-2xl flex items-center justify-center mx-auto text-zinc-500"><Info className="w-8 h-8" /></div>
                <h4 className="font-bold text-zinc-100">Editor Info</h4>
                <p className="text-xs text-zinc-500 leading-relaxed">Fill out the main form to configure basic part details. Switch to visual views to arrange geometry.</p>
              </div>
            ) : (
              <div className="animate-in slide-in-from-right duration-300">
                {!selectedRef ? (
                  <>
                    <PanelHeader title="Canvas View" subtitle="View Settings" icon={Ruler} />
                    <div className="p-4 space-y-6">
                      <InspectorField label="Snap Radius (px)" horizontal><DebouncedNumber value={ui.snapRadius} onChange={v => dispatch({type: 'SET_SNAP_RADIUS', payload: v})} /></InspectorField>
                      <InspectorField label="Toggle Grid" horizontal><button onClick={() => dispatch({type: 'TOGGLE_GRID'})} className={`w-8 h-4 rounded-full transition-all relative ${ui.gridEnabled ? 'bg-indigo-600' : 'bg-zinc-700'}`}><div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all ${ui.gridEnabled ? 'left-4.5' : 'left-0.5'}`} /></button></InspectorField>
                      <div className="pt-6 border-t border-zinc-800">
                         <button onClick={() => { const name = prompt("Connector Name", generateNextPinName(part.connectors)); if (name) dispatch({ type: 'ADD_CONNECTOR', payload: { id: generateUUID(), name, type: 'male', shapeIds: {}, padSpec: { padShape: 'round', padWidth: 2, padHeight: 2, holeDiameter: 0.8 } } }); }} className="w-full py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg text-xs font-bold transition-all">+ Add Connector</button>
                      </div>
                    </div>
                  </>
                ) : selectedShape ? (
                  <>
                    <PanelHeader title="Shape Inspector" subtitle={selectedShape.type} icon={Square} />
                    <div className="p-4 space-y-6">
                       <InspectorField label="Label"><DebouncedInput value={selectedShape.name || ''} onChange={v => dispatch({type: 'UPDATE_SHAPE', view: ui.activeView as ViewType, id: selectedShape.id, payload: {name: v}})} /></InspectorField>
                       <ShapeProps shape={selectedShape} view={ui.activeView as ViewType} dispatch={dispatch} />
                       <button onClick={() => dispatch({ type: 'DELETE_SHAPES', view: ui.activeView as ViewType, ids: [selectedShape.id] })} className="w-full py-2.5 text-red-500 hover:bg-red-500/10 rounded-lg text-xs font-bold border border-red-500/20 transition-all flex items-center justify-center gap-2 mt-4"><Trash2 className="w-3.5 h-3.5" /> Delete Element</button>
                    </div>
                  </>
                ) : selectedConn ? (
                  <>
                    <PanelHeader title="Connector" subtitle={`Pin: ${selectedConn.name}`} icon={Plug} />
                    <div className="p-4 space-y-6">
                      <InspectorField label="Pin Name"><DebouncedInput value={selectedConn.name} onChange={v => dispatch({type: 'UPDATE_CONNECTOR', id: selectedConn.id, payload: {name: v}})} /></InspectorField>
                      <div className="grid grid-cols-2 gap-3">
                        <InspectorField label="Type"><select className="w-full bg-zinc-950 border border-zinc-800 rounded p-1.5 text-xs text-white outline-none" value={selectedConn.type} onChange={e => dispatch({type: 'UPDATE_CONNECTOR', id: selectedConn.id, payload: {type: e.target.value as any}})}><option value="male">Male</option><option value="female">Female</option><option value="pad">Pad</option><option value="wire">Wire</option></select></InspectorField>
                        <InspectorField label="Dir"><select className="w-full bg-zinc-950 border border-zinc-800 rounded p-1.5 text-xs text-white outline-none" value={selectedConn.direction || 'bidirectional'} onChange={e => dispatch({type: 'UPDATE_CONNECTOR', id: selectedConn.id, payload: {direction: e.target.value as any}})}><option value="bidirectional">Bidi</option><option value="input">In</option><option value="output">Out</option><option value="power">Pwr</option></select></InspectorField>
                      </div>
                      
                      {ui.activeView === 'pcb' && (
                        <div className="pt-6 border-t border-zinc-800 space-y-4">
                          <p className="text-[10px] font-black text-zinc-600 uppercase tracking-widest">PCB Footprint (mm)</p>
                          
                          {/* SMD vs THT Toggle */}
                          <div className="flex bg-zinc-950 p-1 rounded-lg border border-zinc-800">
                              <button onClick={() => dispatch({type: 'UPDATE_PAD_SPEC', id: selectedConn.id, payload: {holeDiameter: 0.8, padShape: 'round'}})} className={`flex-1 py-1.5 text-[10px] font-bold rounded-md transition-all ${selectedConn.padSpec.holeDiameter && selectedConn.padSpec.holeDiameter > 0 ? 'bg-indigo-600 text-white shadow-lg' : 'text-zinc-500 hover:text-zinc-300'}`}>THT</button>
                              <button onClick={() => dispatch({type: 'UPDATE_PAD_SPEC', id: selectedConn.id, payload: {holeDiameter: 0, padShape: 'rect'}})} className={`flex-1 py-1.5 text-[10px] font-bold rounded-md transition-all ${!selectedConn.padSpec.holeDiameter ? 'bg-indigo-600 text-white shadow-lg' : 'text-zinc-500 hover:text-zinc-300'}`}>SMD</button>
                          </div>

                          <InspectorField label="Pad Shape"><select className="w-full bg-zinc-950 border border-zinc-800 rounded p-1.5 text-xs text-white outline-none" value={selectedConn.padSpec.padShape} onChange={e => dispatch({type: 'UPDATE_PAD_SPEC', id: selectedConn.id, payload: {padShape: e.target.value as any}})}><option value="round">Round</option><option value="square">Square</option><option value="oblong">Oblong</option><option value="rect">Rect</option></select></InspectorField>
                          <div className="grid grid-cols-2 gap-3">
                            <InspectorField label="Width"><DebouncedNumber value={selectedConn.padSpec.padWidth} onChange={v => dispatch({type: 'UPDATE_PAD_SPEC', id: selectedConn.id, payload: {padWidth: v}})} /></InspectorField>
                            <InspectorField label="Height"><DebouncedNumber value={selectedConn.padSpec.padHeight} onChange={v => dispatch({type: 'UPDATE_PAD_SPEC', id: selectedConn.id, payload: {padHeight: v}})} /></InspectorField>
                          </div>
                          <InspectorField label="Drill Hole"><DebouncedNumber value={selectedConn.padSpec.holeDiameter || 0} onChange={v => dispatch({type: 'UPDATE_PAD_SPEC', id: selectedConn.id, payload: {holeDiameter: v}})} /></InspectorField>
                        </div>
                      )}
                      
                      <button onClick={() => dispatch({ type: 'DELETE_CONNECTOR', id: selectedConn.id })} className="w-full py-2.5 text-red-500 hover:bg-red-500/10 rounded-lg text-xs font-bold border border-red-500/20 transition-all flex items-center justify-center gap-2 mt-4"><Trash2 className="w-3.5 h-3.5" /> Remove Pin</button>
                    </div>
                  </>
                ) : null}
              </div>
            )}
          </aside>
        </main>
      </div>

      {ui.modals.generator && <GeneratorModal onClose={() => dispatch({type: 'SET_MODAL_OPEN', modal: 'generator', isOpen: false})} dispatch={dispatch} />}
      {ui.modals.validation && <ValidationModal issues={ui.validationIssues} onClose={() => dispatch({type: 'SET_MODAL_OPEN', modal: 'validation', isOpen: false})} />}
      {ui.modals.modify && <ModifyModal onClose={() => dispatch({type: 'SET_MODAL_OPEN', modal: 'modify', isOpen: false})} dispatch={dispatch} currentContent={{
          shapes: {
              breadboard: part.views.breadboard.shapes,
              schematic: part.views.schematic.shapes,
              pcb: part.views.pcb.shapes
          },
          connectors: part.connectors
      }} />}
    </div>
  );
}