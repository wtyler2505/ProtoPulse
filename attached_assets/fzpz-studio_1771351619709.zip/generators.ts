
import { Shape, Connector, GenOptions, ViewType, GenOptionsIC, GenOptionsDiscrete } from './types';
import { generateUUID } from './utils';
import { GoogleGenAI } from "@google/genai";

// Helper to create a partial state update
export interface GeneratedContent {
  shapes: Record<ViewType, Shape[]>;
  connectors: Connector[];
}

// Constants
const MM_TO_UNITS = 3.93701 * 10; // 1mm = ~39.37 mils (approx 40 units for grid alignment preference)
const MM = 39.3701;

// --- HELPERS ---

function createPinName(i: number): string {
  return (i + 1).toString();
}

// Helper to strip Markdown code blocks from JSON response
function cleanJson(text: string): string {
    if (!text) return "{}";
    // Remove markdown code blocks like ```json ... ```
    let cleaned = text.replace(/```json/g, '').replace(/```/g, '');
    // Find the first '{' and the last '}' to ensure we only try to parse the object
    const firstOpen = cleaned.indexOf('{');
    const lastClose = cleaned.lastIndexOf('}');
    if (firstOpen !== -1 && lastClose !== -1) {
        cleaned = cleaned.substring(firstOpen, lastClose + 1);
    }
    return cleaned.trim();
}

export function generatePackage(options: GenOptions): GeneratedContent {
  
  if (options.family === 'Resistor' || options.family === 'Capacitor') {
      return generateDiscrete(options as GenOptionsDiscrete);
  } else {
      return generateIC(options as GenOptionsIC);
  }
}

// --- AI GENERATOR ---

const SYSTEM_PROMPT = `You are a Senior Fritzing Part Designer & SVG Illustrator AI.
Your goal is to generate **production-grade, photorealistic, and dimensionally accurate** component definitions.

OUTPUT FORMAT:
Return ONLY a raw JSON object matching the 'GeneratedContent' interface defined below. Do NOT include markdown formatting (like \`\`\`json).

UNITS & COORDINATES:
- Unit: MILS (1/1000 inch).
- 100 units = 2.54mm (Standard breadboard pitch).
- Origin (0,0) is top-left.

INTERFACES:
type ShapeType = "rect" | "circle" | "path" | "text" | "group";
interface Shape {
  id: string; // Use UUIDs or descriptive IDs like "usb_shell"
  type: ShapeType;
  x: number; y: number;
  // rect:
  w?: number; h?: number; rx?: number; ry?: number;
  // circle:
  r?: number;
  // path:
  d?: string;
  // text:
  content?: string; fontSize?: number; fontFamily?: string; textAnchor?: "start" | "middle" | "end";
  
  fill?: string; stroke?: string; strokeWidth?: number; opacity?: number;
  rotation?: number; rotationOrigin?: {x: number, y: number};
}

interface Connector {
  id: string;
  name: string;
  type: "male" | "female" | "pad" | "wire";
  shapeIds: { breadboard: string; schematic: string; pcb: string; };
  breadboardTerminal?: { x: number; y: number };
  schematicTerminal?: { x: number; y: number };
  pcbTerminal?: { x: number; y: number };
  padSpec: { padShape: "round"|"square"|"rect"|"oblong"; padWidth: number; padHeight: number; holeDiameter: number; };
}

interface GeneratedContent {
  shapes: {
    breadboard: Shape[];
    schematic: Shape[];
    pcb: Shape[];
  };
  connectors: Connector[];
}

VISUAL STYLE & ACCURACY RULES (CRITICAL):

1. **BREADBOARD VIEW (High Fidelity Illustration)**:
   - **Context**: This resembles a photograph of the real part.
   - **Board**: Use accurate PCB colors (Arduino Teal #00878F, Sparkfun Red #E62C2E, Adafruit Blue #0099CC, Generic Green #336633).
   - **Components**: Draw ALL visible components. Do not leave the board empty.
     - **Main IC**: Draw the microcontroller (e.g., ATmega2560, ESP32). Use a black square/rect, often rotated 45° for QFP packages. Draw faint gray pins around it.
     - **USB Port**: Draw the specific connector clearly. 
        - Micro-USB: Silver trapezoid with small indentations.
        - USB-C: Oval silver shell with black inner contact strip.
        - Type-B: Silver square with bevelled top corners.
     - **Power Jack**: Black block with silver contacts.
     - **Regulators**: SOT-223 packages (black rect + large heat tab).
     - **Crystal**: Silver metallic oval or tiny metal rectangle.
     - **Reset Button**: Tactile switch (Silver/Black housing, circular button).
     - **LEDs**: Small rectangles or circles. Colors: Power (Green), L (Amber/Yellow), TX/RX (Yellow).
     - **Passive Components**: Tiny 0603/0805 resistors/capacitors (Tan/Black/White small rects).
   - **Headers**:
     - **DO NOT** draw a single long rectangle for a header strip.
     - Draw **individual** black plastic squares for each pin position.
     - **GAPS**: Respect standard gaps! (e.g., Arduino Uno has a gap between Digital 7 and 8). Match the real layout.
   - **Silkscreen**: Add white text (#FFFFFF, opacity 0.8) for pin labels (5V, GND, A0, D13, TX, RX) and Board Name.
   - **Text Compatibility**: ALWAYS use "OCRA" as the fontFamily for all text elements. This is required for Fritzing compatibility.

2. **SCHEMATIC VIEW (Symbol)**:
   - Functional schematic symbol.
   - Rectangle body.
   - **GRID ALIGNMENT**: All pins MUST align to a 100-mil grid (e.g., y=0, y=100, y=200).
   - **PIN GROUPING**: Group pins logically by function (Power, Analog, Digital, Comm) rather than physical order.
   - Pin names inside the box.
   - Use "OCRA" font family.

3. **PCB VIEW (Footprint)**:
   - **Manufacturing Ready**.
   - **Pads**: Gold (#D4AF37) or Silver (#C0C0C0).
   - **THT**: Ring shape with hole (holeDiameter > 0).
   - **SMD**: Solid Rect shape (holeDiameter = 0).
   - **Outline**: White silkscreen line showing component bounds.

4. **PIN MAPPING & NAMING**:
   - **Smart Naming**: Use standard, meaningful names (e.g., 'VCC', 'GND', 'SDA', 'SCL', 'D13', 'A0') instead of generic numbers where possible. Infer functionality from the component type.
   - Ensure the 'connectors' list matches the shapes.
   - 'shapeIds.breadboard' should point to the specific visual element (e.g., the silver metal part of the header pin) for that connector.

THINKING PROCESS:
1. Review the PROVIDED SPECS (from the research phase).
2. Layout shapes in Mils based on those specific dimensions.
3. Generate JSON.
`;

/**
 * PHASE 1: RESEARCH
 * Uses Gemini Flash with Google Search to find real-world data.
 */
async function researchComponent(description: string, apiKey: string): Promise<string> {
    const ai = new GoogleGenAI({ apiKey });
    console.log("Starting Research Phase for:", description);
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Find technical specifications for: "${description}".
            I need the following data to design a PCB footprint and breadboard view:
            1. Exact Board Dimensions (width x height in mm).
            2. Pin Pitch (e.g., 2.54mm, 1.27mm).
            3. Pinout Table (Pin Label vs Function).
            4. Key components on board (e.g., "USB-C", "SOT-223 Regulator").
            5. Mounting hole locations if applicable.
            
            Summarize this as a structured technical brief. Include URLs of sources found.`,
            config: {
                tools: [{ googleSearch: {} }],
            }
        });
        
        if (response.candidates?.[0]?.groundingMetadata?.groundingChunks) {
            console.log("Found Grounding Data:", response.candidates[0].groundingMetadata.groundingChunks);
        }

        return response.text || "No specific specs found. Rely on general knowledge.";
    } catch (e) {
        console.warn("Research phase failed, falling back to internal knowledge:", e);
        return "Search failed. Use internal training data.";
    }
}

/**
 * PHASE 2: GENERATION
 * Uses Gemini Pro with Thinking to build the part using the research data.
 */
export async function generatePartWithAI(description: string, apiKey: string, attachment?: { mimeType: string, data: string }): Promise<GeneratedContent> {
    if (!apiKey) throw new Error("API Key is required");
    const ai = new GoogleGenAI({ apiKey });

    try {
        const parts: any[] = [];
        let researchedSpecs = "";

        // Only perform search if no attachment is provided
        if (!attachment) {
            researchedSpecs = await researchComponent(description, apiKey);
        }
        
        // Add attachment if present
        if (attachment) {
             parts.push({ inlineData: attachment });
             parts.push({ text: "Analyze the attached image/datasheet to extract pinouts, dimensions, and visual details." });
        }

        const mainPrompt = `Generate a Fritzing part for: "${description}". 
            
CONTEXT & SPECS (From Research/Attachment):
${researchedSpecs}

REQUIREMENTS:
1. **Photorealistic Breadboard View**: Draw the actual board with all chips, USB ports, regulators, capacitors, and text labels. It should look like a vector illustration of the photo.
2. **Accurate Headers**: Draw individual pin sockets. Respect real-world spacing and gaps (e.g. Arduino headers are not continuous).
3. **Complete Pinout**: Generate all accessible pins defined on the board.
4. **Smart Pin Names**: Use "VCC", "GND", "TX", "RX" etc. based on the verified specs.
`;
        parts.push({ text: mainPrompt });

        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: { parts },
            config: {
                systemInstruction: SYSTEM_PROMPT,
                responseMimeType: "application/json",
                thinkingConfig: { thinkingBudget: 32768 } // Enable MAX reasoning
            }
        });

        const text = response.text || "";
        if (!text) throw new Error("AI returned empty response");

        // CLEAN AND PARSE JSON
        const cleanedJson = cleanJson(text);
        let data: GeneratedContent;
        
        try {
            data = JSON.parse(cleanedJson) as GeneratedContent;
        } catch (parseError) {
            console.error("JSON Parse Error. Raw Text:", text);
            console.error("Cleaned Text:", cleanedJson);
            throw new Error("Failed to parse AI response. See console for details.");
        }

        // Post-process
        const safeShapes = (arr: any[]) => Array.isArray(arr) ? arr.map(s => ({ ...s, id: s.id || generateUUID() })) : [];
        
        return {
            shapes: {
                breadboard: safeShapes(data.shapes?.breadboard),
                schematic: safeShapes(data.shapes?.schematic),
                pcb: safeShapes(data.shapes?.pcb),
            },
            connectors: Array.isArray(data.connectors) ? data.connectors.map(c => ({
                ...c,
                id: c.id || generateUUID(),
                padSpec: c.padSpec || { padShape: 'round', padWidth: 60, padHeight: 60, holeDiameter: 35 }
            })) : []
        };

    } catch (e) {
        console.error("AI Generation failed", e);
        throw e;
    }
}

export async function modifyPartWithAI(current: GeneratedContent, instruction: string, apiKey: string): Promise<GeneratedContent> {
    if (!apiKey) throw new Error("API Key is required");
    const ai = new GoogleGenAI({ apiKey });

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: `Here is the current JSON definition of a Fritzing part:
${JSON.stringify(current)}

USER INSTRUCTION:
${instruction}

TASK:
Modify the part definition according to the user's instruction. 
- Return the FULL updated JSON object.
- Preserve existing IDs where possible to maintain references.
- Maintain the visual style and coordinate system (Mils).
`,
            config: {
                systemInstruction: SYSTEM_PROMPT,
                responseMimeType: "application/json",
                thinkingConfig: { thinkingBudget: 16000 }
            }
        });

        const text = response.text || "";
        if (!text) throw new Error("AI returned empty response");

        const cleanedJson = cleanJson(text);
        const data = JSON.parse(cleanedJson) as GeneratedContent;
        
        const safeShapes = (arr: any[]) => Array.isArray(arr) ? arr.map(s => ({ ...s, id: s.id || generateUUID() })) : [];
        
        return {
             shapes: {
                breadboard: safeShapes(data.shapes?.breadboard),
                schematic: safeShapes(data.shapes?.schematic),
                pcb: safeShapes(data.shapes?.pcb),
            },
            connectors: Array.isArray(data.connectors) ? data.connectors.map(c => ({
                ...c,
                id: c.id || generateUUID(),
                padSpec: c.padSpec || { padShape: 'round', padWidth: 60, padHeight: 60, holeDiameter: 35 }
            })) : []
        };
    } catch (e) {
        console.error("AI Modification failed", e);
        throw e;
    }
}

// --- DISCRETE GENERATOR (Resistors, Caps) ---
function generateDiscrete(options: GenOptionsDiscrete): GeneratedContent {
    const { family, packageCode } = options;
    const isRes = family === 'Resistor';
    
    const shapes: Record<ViewType, Shape[]> = { breadboard: [], schematic: [], pcb: [] };
    const connectors: Connector[] = [];

    // Dimensions (mm)
    let length = 0, width = 0, padL = 0, padW = 0;
    
    switch(packageCode) {
        case '0402': length = 1.0; width = 0.5; padL = 0.6; padW = 0.6; break;
        case '0603': length = 1.6; width = 0.8; padL = 0.8; padW = 0.8; break;
        case '0805': length = 2.0; width = 1.25; padL = 1.0; padW = 1.3; break;
        case '1206': length = 3.2; width = 1.6; padL = 1.1; padW = 1.7; break;
        default: length = 2.0; width = 1.25; padL = 1.0; padW = 1.3;
    }

    const L = length * MM;
    const W = width * MM;
    const bodyX = 100;
    const bodyY = 100;

    // -- Breadboard View --
    const bodyId = generateUUID();
    // Main Body
    shapes.breadboard.push({
        id: bodyId, type: 'rect',
        x: bodyX, y: bodyY, w: L, h: W,
        fill: isRes ? '#16161d' : '#947153', stroke: 'none', rx: 2, ry: 2
    });
    
    // Terminals (Silver)
    const termWidth = (L * 0.2);
    shapes.breadboard.push({
        id: generateUUID(), type: 'rect',
        x: bodyX, y: bodyY, w: termWidth, h: W,
        fill: '#e4e4e7', stroke: 'none', rx: 1, ry: 1
    });
    shapes.breadboard.push({
        id: generateUUID(), type: 'rect',
        x: bodyX + L - termWidth, y: bodyY, w: termWidth, h: W,
        fill: '#e4e4e7', stroke: 'none', rx: 1, ry: 1
    });

    if (isRes) {
        // Resistor Band Code (Fake)
        shapes.breadboard.push({ id: generateUUID(), type: 'rect', x: bodyX + (L*0.3), y: bodyY, w: L*0.1, h: W, fill: '#ef4444' }); // Red
        shapes.breadboard.push({ id: generateUUID(), type: 'rect', x: bodyX + (L*0.5), y: bodyY, w: L*0.1, h: W, fill: '#a855f7' }); // Purple
        shapes.breadboard.push({ id: generateUUID(), type: 'rect', x: bodyX + (L*0.7), y: bodyY, w: L*0.1, h: W, fill: '#000000' }); // Black
    } else {
        // Capacitor text
        shapes.breadboard.push({
            id: generateUUID(), type: 'text',
            x: bodyX + L/2, y: bodyY + W/2 + 2, content: "10uF",
            fontSize: W/3, fill: '#553311', textAnchor: 'middle', fontFamily: 'Arial'
        });
    }

    // -- Schematic View --
    const schW = 60;
    const schH = 20;
    const schX = 0; 
    const schY = 0;
    
    if (isRes) {
        // Zig Zag
        shapes.schematic.push({
            id: generateUUID(), type: 'path',
            x: 0, y: 0, 
            d: `M 10 10 L 15 5 L 25 15 L 35 5 L 45 15 L 50 10`,
            stroke: '#000', strokeWidth: 1.5, fill: 'none'
        });
    } else {
        // Capacitor Plates
        shapes.schematic.push({ id: generateUUID(), type: 'rect', x: 25, y: 2, w: 2, h: 16, fill: '#000' });
        shapes.schematic.push({ id: generateUUID(), type: 'rect', x: 33, y: 2, w: 2, h: 16, fill: '#000' });
    }

    // -- Connectors --
    const pins = [0, 1];
    pins.forEach(i => {
        const connId = generateUUID();
        const pcbPadId = generateUUID();
        const schPinId = generateUUID();
        const bbPinId = generateUUID(); // Invisible, just for linking

        // PCB Pad
        const px = i === 0 ? bodyX - (padL*MM)/2 : bodyX + L - (padL*MM)/2;
        shapes.pcb.push({
            id: pcbPadId, type: 'rect',
            x: px, y: bodyY, w: padL*MM, h: padW*MM,
            fill: '#d4af37'
        });

        // Schematic Pin Line
        shapes.schematic.push({
            id: schPinId, type: 'path',
            x: 0, y: 0,
            d: i===0 ? `M 0 10 L 10 10` : `M 50 10 L 60 10`,
            stroke: '#000', strokeWidth: 1
        });

        connectors.push({
            id: connId,
            name: i === 0 ? '1' : '2',
            type: 'pad',
            padSpec: { padShape: 'rect', padWidth: padL, padHeight: padW } as any,
            shapeIds: { pcb: pcbPadId, schematic: schPinId, breadboard: bodyId },
            pcbTerminal: { x: px + (padL*MM)/2, y: bodyY + (padW*MM)/2 },
            schematicTerminal: { x: i===0?0:60, y: 10 },
            breadboardTerminal: { x: i===0 ? bodyX : bodyX+L, y: bodyY+W/2 }
        });
    });

    return { shapes, connectors };
}

// --- IC GENERATOR (DIP, SOIC, QFP, QFN) ---
function generateIC(options: GenOptionsIC): GeneratedContent {
  const { family, pinCount, pitch_mm, rowSpacing_mm, bodyWidth_mm, bodyLength_mm, thermalPad } = options;
  const pitch = pitch_mm * MM;
  
  const shapes: Record<ViewType, Shape[]> = { breadboard: [], schematic: [], pcb: [] };
  const connectors: Connector[] = [];

  const isQuad = family === 'QFP' || family === 'QFN';
  const isDIP = family === 'DIP';
  
  // Dimensions
  // If body dims not provided, estimate them
  const pinsPerSide = isQuad ? Math.floor(pinCount / 4) : Math.floor(pinCount / 2);
  
  const calcBodyL = bodyLength_mm ? bodyLength_mm * MM : (isQuad ? (pinsPerSide * pitch + 20) : (pinsPerSide * pitch + 20));
  const calcBodyW = bodyWidth_mm ? bodyWidth_mm * MM : (rowSpacing_mm ? (rowSpacing_mm * MM) - 30 : (isQuad ? calcBodyL : 300));

  const bodyX = 100;
  const bodyY = 100;

  // --- Breadboard Body ---
  // Plastic Body
  shapes.breadboard.push({
    id: generateUUID(), type: 'rect',
    x: bodyX, y: bodyY, w: calcBodyW, h: calcBodyL,
    fill: '#27272a', stroke: '#18181b', strokeWidth: 1, rx: 2, ry: 2, name: 'IC Body'
  });
  // Pin 1 Indicator (Dot)
  shapes.breadboard.push({
    id: generateUUID(), type: 'circle',
    x: bodyX + (calcBodyW * 0.15), y: bodyY + (calcBodyW * 0.15), r: calcBodyW * 0.05,
    fill: '#52525b', stroke: 'none'
  });
  // Label
  shapes.breadboard.push({
      id: generateUUID(), type: 'text',
      x: bodyX + calcBodyW/2, y: bodyY + calcBodyL/2, content: family,
      fontSize: Math.min(calcBodyW, calcBodyL) * 0.3, fill: '#71717a', 
      rotation: isQuad ? 0 : -90, 
      rotationOrigin: {x: bodyX + calcBodyW/2, y: bodyY + calcBodyL/2},
      textAnchor: 'middle', fontFamily: 'OCRA' // Enforce OCRA here too
  });

  // --- PCB Silkscreen ---
  shapes.pcb.push({
      id: generateUUID(), type: 'rect',
      x: bodyX - 5, y: bodyY - 5, w: calcBodyW + 10, h: calcBodyL + 10,
      fill: 'none', stroke: '#ffffff', strokeWidth: 1, rx: 1, ry: 1
  });

  // --- Schematic Body ---
  const schW = 150;
  const schH = (Math.max(pinCount/2, 4) * 20) + 20; // Ensure logic handles height
  shapes.schematic.push({
      id: generateUUID(), type: 'rect',
      x: 0, y: 0, w: schW, h: schH,
      fill: '#ffffff', stroke: '#000000', strokeWidth: 2
  });
  shapes.schematic.push({
      id: generateUUID(), type: 'text',
      x: schW/2, y: 15, content: "IC",
      fontSize: 12, textAnchor: 'middle', fill: '#000', fontFamily: 'OCRA'
  });

  // --- PIN GENERATION LOOP ---
  for (let i = 0; i < pinCount; i++) {
      const connId = generateUUID();
      const bbShapeId = generateUUID();
      const pcbShapeId = generateUUID();
      const schShapeId = generateUUID();

      let pinX = 0, pinY = 0; // Relative to 0,0 for ease, then shift
      let pcbX = 0, pcbY = 0;
      let schX = 0, schY = 0;
      let schLabelX = 0;
      let bbW = 0, bbH = 0;

      // --- Geometry Logic ---
      if (isQuad) {
          // 4 sides: Top, Left, Bottom, Right? Or counter-clockwise from top-left?
          // Standard: CCW starting from top-left side (Left edge) or Top edge depending on standard.
          // Let's assume standard QFP: Pin 1 Top-Left (Left Side), moving down, then Bottom, then Right, then Top.
          const side = Math.floor(i / pinsPerSide); // 0=Left, 1=Bottom, 2=Right, 3=Top
          const idx = i % pinsPerSide;

          const midOff = ((pinsPerSide - 1) * pitch) / 2;
          const offset = (idx * pitch) - midOff;

          if (side === 0) { // Left
             pinX = bodyX - 10; pinY = bodyY + (calcBodyL/2) + offset;
             pcbX = bodyX - 15; pcbY = pinY;
          } else if (side === 1) { // Bottom
             pinX = bodyX + (calcBodyW/2) + offset; pinY = bodyY + calcBodyL;
             pcbX = pinX; pcbY = bodyY + calcBodyL + 5;
          } else if (side === 2) { // Right
             pinX = bodyX + calcBodyW; pinY = bodyY + (calcBodyL/2) - offset;
             pcbX = bodyX + calcBodyW + 5; pcbY = pinY;
          } else { // Top
             pinX = bodyX + (calcBodyW/2) - offset; pinY = bodyY - 10;
             pcbX = pinX; pcbY = bodyY - 15;
          }
          bbW = (side % 2 === 0) ? 10 : 6;
          bbH = (side % 2 === 0) ? 6 : 10;

      } else {
          // Dual row (DIP/SOIC)
          const isLeft = i < (pinCount / 2);
          const idx = isLeft ? i : (i - pinCount/2);
          const rowY = (idx * pitch) + (isDIP ? 20 : 10);
          
          if (isLeft) {
             pinX = bodyX - (isDIP?5:10); 
             pinY = bodyY + rowY;
             pcbX = bodyX - 10;
          } else {
             // Right side goes UP usually? Or down? Standard DIP numbering: Down Left, Up Right.
             // idx 0 is bottom-most on right side
             const invIdx = (pinCount/2) - 1 - idx;
             const invRowY = (invIdx * pitch) + (isDIP ? 20 : 10);
             pinX = bodyX + calcBodyW - (isDIP?5:0);
             pinY = bodyY + invRowY;
             pcbX = bodyX + calcBodyW + 10;
          }
          pcbY = pinY;
          bbW = isDIP ? 10 : 14; bbH = isDIP ? 10 : 6;
      }

      // Schematic Positioning - 100mil grid (approx 2.54mm = 100 units in our system if 100units=2.54mm)
      // Actually MM = 39.37. So 100 mils = 2.54 * 39.37 = 100. Correct.
      const isSchLeft = i < pinCount/2;
      const schIdx = i % (Math.ceil(pinCount/2));
      schY = 100 + (schIdx * 100); // 100 mil grid spacing
      if (i < pinCount/2) {
          schX = -100;
          schLabelX = 10;
      } else {
          schX = schW + 100;
          schLabelX = schW - 10;
      }

      // --- Create Shapes ---

      // BB
      shapes.breadboard.push({
          id: bbShapeId, type: 'rect',
          x: pinX, y: pinY, w: bbW, h: bbH,
          fill: '#e4e4e7', stroke: 'none' // Silver
      });

      // PCB
      const isTHT = family === 'DIP' || family === 'Header';
      if (isTHT) {
          shapes.pcb.push({
              id: pcbShapeId, type: 'circle',
              x: pcbX + 7, y: pcbY + 5, r: 7,
              fill: 'none', stroke: '#d4af37', strokeWidth: 4
          });
      } else {
          // SMD Pad
          shapes.pcb.push({
              id: pcbShapeId, type: 'rect',
              x: pcbX, y: pcbY, w: 14, h: 8,
              fill: '#d4af37', stroke: 'none'
          });
      }

      // Schematic
      shapes.schematic.push({
          id: schShapeId, type: 'path',
          x: 0, y: 0, d: i < pinCount/2 ? `M 0 ${schY} L -100 ${schY}` : `M ${schW} ${schY} L ${schW+100} ${schY}`,
          stroke: '#000', strokeWidth: 1
      });
      shapes.schematic.push({
          id: generateUUID(), type: 'text',
          x: schLabelX, y: schY + 10, content: createPinName(i),
          fontSize: 30, fill: '#000', fontFamily: 'OCRA',
          textAnchor: i < pinCount/2 ? 'start' : 'end'
      });

      connectors.push({
          id: connId,
          name: createPinName(i),
          type: isTHT ? 'male' : 'pad',
          padSpec: { padShape: isTHT?'round':'rect', padWidth: 1.5, padHeight: 1.5, holeDiameter: isTHT?0.8:0 } as any,
          shapeIds: { breadboard: bbShapeId, schematic: schShapeId, pcb: pcbShapeId },
          breadboardTerminal: { x: pinX + bbW/2, y: pinY + bbH/2 },
          pcbTerminal: { x: pcbX + 7, y: pcbY + 5 },
          schematicTerminal: { x: i<pinCount/2 ? -100 : schW+100, y: schY }
      });
  }

  // Thermal Pad
  if (thermalPad && isQuad) {
      const tpId = generateUUID();
      const padW = calcBodyW * 0.6;
      const padH = calcBodyL * 0.6;
      shapes.pcb.push({
          id: tpId, type: 'rect',
          x: bodyX + (calcBodyW - padW)/2, y: bodyY + (calcBodyL - padH)/2,
          w: padW, h: padH, fill: '#d4af37', opacity: 0.5
      });
  }

  return { shapes, connectors };
}
