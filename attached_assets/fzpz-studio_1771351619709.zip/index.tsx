import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

class ErrorBoundary extends React.Component<{children?: React.ReactNode}, {hasError: boolean, error: Error | null}> {
  state: { hasError: boolean, error: Error | null };
  props: { children?: React.ReactNode };

  constructor(props: {children?: React.ReactNode}) {
    super(props);
    this.props = props;
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-8 h-screen w-screen bg-neutral-950 text-neutral-300 flex flex-col items-center justify-center font-sans">
          <div className="max-w-2xl bg-neutral-900 border border-red-900 rounded-lg p-6 shadow-2xl">
              <h1 className="text-xl font-bold text-red-500 mb-2 flex items-center">
                  <svg className="w-6 h-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                  FZPZ Studio Crashed
              </h1>
              <p className="text-sm mb-4">An unexpected error occurred. The UI could not render.</p>
              <pre className="bg-black p-4 rounded text-xs text-red-400 overflow-x-auto border border-neutral-800">
                  {this.state.error?.message}
              </pre>
              <button 
                  onClick={() => window.location.reload()} 
                  className="mt-6 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded font-medium text-sm transition-colors"
              >
                  Reload Application
              </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <ErrorBoundary>
        <App />
    </ErrorBoundary>
  </React.StrictMode>
);